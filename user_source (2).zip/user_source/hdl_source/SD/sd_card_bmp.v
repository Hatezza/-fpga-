
module sd_card_bmp #(
    parameter integer CLK_FREQ_HZ       = 100_000_000,
    parameter [31:0]  SCAN_START_SECTOR = 32'd0,
    parameter [31:0]  SCAN_MAX_SECTOR   = 32'd131071,
    parameter [2:0]   SCAN_TARGET_COUNT = 3'd4
)(
    input                       clk,
    input                       rst,
    input                       key_next,
    input                       key_auto,
    input                       home_req,       // 回到主页菜单：加载第一张图（主页背景）
    input                       home_mode,      // 1 = 主页菜单模式（暂停自动轮播）
    input                       disp_req,       // 进入图片调节模式：加载第 2 张图
    input  [15:0]               bmp_width,
    input  [15:0]               bmp_height,
    output reg                  display_valid,
    output      [3:0]           state_code,

    input                       write_finish_toggle,
    output reg [1:0]            write_buf_idx,
    output reg [1:0]            disp_buf_idx,

    output                      write_req,
    input                       write_req_ack,
    output                      write_en,
    output [31:0]               write_data,

    // 当前加载图的真实源尺寸（缩放前），供观测/调试
    output [15:0]               o_src_width,
    output [15:0]               o_src_height,
    output [2:0]                o_found_count,   // 扫描到的图片数（顶层数码管诊断）

    output                      SD_nCS,
    output                      SD_DCLK,
    output                      SD_MOSI,
    input                       SD_MISO
);

wire key_next_press;
wire key_auto_press;

wire             sd_sec_read;
wire [31:0]      sd_sec_read_addr;
wire [7:0]       sd_sec_read_data;
wire             sd_sec_read_data_valid;
wire             sd_sec_read_end;
wire [3:0]       state_code_i;
wire             bmp_data_wr_en;
wire [23:0]      bmp_data;
wire             sd_init_done;
wire             bmp_ready;
wire             scan_done;
wire             scan_found_valid;
wire [31:0]      scan_found_sector;
wire [2:0]       scan_found_total;

reg              scan_start_pulse;
reg              load_start_pulse;
reg [31:0]       load_sector;
reg              scan_kicked;
reg              first_image_committed;
reg              auto_play_en;
reg [31:0]       auto_cnt;
reg [2:0]        img_found_count;
reg [1:0]        img_idx;              // 当前真正显示中的图片编号
reg [1:0]        load_idx;             // 当前正在写入的图片编号
reg [1:0]        pending_buf_idx;      // 当前正在写入的目标缓冲区
reg [31:0]       img_sector0;
reg [31:0]       img_sector1;
reg [31:0]       img_sector2;
reg [31:0]       img_sector3;
reg              next_req_pending;
reg              home_req_pending;      // 主页跳转请求挂起（任意模式回到菜单时触发）
reg              disp_req_pending;      // 调节模式显示第 2 张请求挂起
reg [1:0]        load_req_kind;         // 在飞加载类型：0=无/首图/自动 1=home 3=next（2 保留）
reg              load_busy;
reg [31:0]       load_timeout_cnt;

// 当前加载图的真实源尺寸，由 bmp_read 头部解析完成脉冲锁存
reg [15:0]       load_src_width;
reg [15:0]       load_src_height;

reg              load_abort;

// bmp_ready 先表示“源文件读取/送 FIFO 完成”；真正切显示要等 write_finish_toggle 同步后
reg              source_done_seen;
reg              write_done_seen;

// 同步 mem_clk 域的 write_finish_toggle
reg [2:0]        wrfin_tgl_sync;
wire             write_finish_pulse;

wire auto_tick;
wire [1:0] next_from_current;

// bmp_read 头部解析结果（真实宽高 + 解析完成脉冲）
wire [15:0] bmp_read_o_width;
wire [15:0] bmp_read_o_height;
wire        bmp_hdr_valid;

// 缩放后的像素与写使能
wire        scl_vld;
wire [23:0] scl_rgb;

// ---- pix_fifo：吸收 scaler EMIT 期间的反压突发 ----
// scaler 的 O_src_ready=0（EMIT 期）时 SPI 读通路无法暂停，由本 FIFO 蓄积
// （EMIT_DIV=8 节流下单行 EMIT 最长 5120 拍 ≈ 流入 54 像素，128 深足够），
// ready 恢复后排空。show-ahead 输出直连 scaler 的 I_de/I_rgb。
wire        fifo_pop;
wire        fifo_empty;
wire [23:0] fifo_dout;
wire        scl_src_ready;

// 宽高锁存：必须用头部解析完成脉冲，而不是 load_start。
// 因为 ST_LOAD_HDR 才解析本图头部，load_start 那一拍 o_width/o_height
// 还是"上一张图"的值，用它锁存会让 scaler 用错尺寸导致画面错乱。
always @(posedge clk or posedge rst) begin
    if (rst) begin
        load_src_width  <= 16'd640;
        load_src_height <= 16'd480;
    end else if (bmp_hdr_valid) begin
        load_src_width  <= bmp_read_o_width;
        load_src_height <= bmp_read_o_height;
    end
end

assign o_src_width  = load_src_width;
assign o_src_height = load_src_height;

// ===================== 写侧最近邻缩放（任意分辨率 → 640×480） =====================
// 插在 bmp_read 与写 FIFO 之间，把源像素流缩放成固定 640×480 再写入 SDRAM。
// 显示通路（video_delay→img_effect→osd_overlay）不受影响。
// O_de 直接作为写使能：其节拍就是 640×480 的线性顺序，与 FRAME_PIXELS 一致，
// 因此 write_finish 的"写完 RW_LEN 个"判定依然成立。
pix_fifo u_pix_fifo (
    .I_clk     (clk),
    .I_rst     (rst),
    .I_wr_en   (bmp_data_wr_en),
    .I_wr_data (bmp_data),
    .I_rd_en   (fifo_pop),
    .O_rd_data (fifo_dout),
    .O_empty   (fifo_empty),
    .O_full    ()
);
assign fifo_pop = scl_src_ready && !fifo_empty;   // 严格握手：ready 才弹

// load_abort 单拍脉冲展宽 4 拍，作为 scaler 的复位：
// 超时中止后 bmp_read 已回 IDLE，scaler 必须同步复位，
// 否则残留半帧状态会让重试帧内容错乱（更胡）。
reg [1:0] scl_rst_cnt;
reg       scl_rst_hold;
always @(posedge clk or posedge rst) begin
    if (rst) begin
        scl_rst_cnt  <= 2'd0;
        scl_rst_hold <= 1'b0;
    end else if (load_abort) begin
        scl_rst_hold <= 1'b1;
        scl_rst_cnt  <= 2'd3;
    end else if (scl_rst_hold) begin
        if (scl_rst_cnt == 2'd0)
            scl_rst_hold <= 1'b0;
        else
            scl_rst_cnt <= scl_rst_cnt - 2'd1;
    end
end
wire scl_rst = rst || scl_rst_hold;

scaler #(
    .OW        (640),
    .OH        (480),
    .MAX_SRC_W (2048),
    .SW_BITS   (12),
    .SH_BITS   (12)
) u_scaler (
    .I_clk        (clk),
    .I_rst        (scl_rst),
    .I_de         (fifo_pop),
    .I_hs         (1'b0),
    .I_vs         (1'b0),
    .I_rgb        (fifo_dout),
    .I_src_width  (load_src_width[11:0]),
    .I_src_height (load_src_height[11:0]),
    .O_rgb        (scl_rgb),
    .O_de         (scl_vld),
    .O_hs         (),
    .O_vs         (),
    .O_src_ready  (scl_src_ready)
);

assign write_en   = scl_vld;
assign write_data = {scl_rgb, 8'b0};
assign auto_tick  = (auto_cnt == (CLK_FREQ_HZ - 1));
assign next_from_current = next_index_limited(img_idx, img_found_count);
assign write_finish_pulse = wrfin_tgl_sync[2] ^ wrfin_tgl_sync[1];
assign state_code = state_code_i;
assign o_found_count = img_found_count;

key_press_debounce #(
    .CLK_FREQ_HZ (CLK_FREQ_HZ),
    .DEBOUNCE_MS (50)
) u_key_next (
    .clk        (clk),
    .rst        (rst),
    .button_in  (key_next),
    .press_pulse(key_next_press)
);

key_press_debounce #(
    .CLK_FREQ_HZ (CLK_FREQ_HZ),
    .DEBOUNCE_MS (50)
) u_key_auto (
    .clk        (clk),
    .rst        (rst),
    .button_in  (key_auto),
    .press_pulse(key_auto_press)
);

function [1:0] next_index_limited;
    input [1:0] cur;
    input [2:0] count;
    begin
        // 第 1 张（index 0）是首页背景，不参与展示轮播：
        // 轮播范围 1..count-1，末张回绕到 1，永不到 0
        if (count <= 3'd1)
            next_index_limited = 2'd0;       // 只有首页：停在首页
        else if (cur == (count - 3'd1))
            next_index_limited = 2'd1;       // 末张回绕到第 2 张（跳过首页）
        else if (cur == 2'd0)
            next_index_limited = 2'd1;       // 首页状态按键 → 直接第 2 张
        else
            next_index_limited = cur + 2'd1;
    end
endfunction

function [31:0] sector_lut;
    input [1:0] idx;
    begin
        case (idx)
            2'd0: sector_lut = img_sector0;
            2'd1: sector_lut = img_sector1;
            2'd2: sector_lut = img_sector2;
            2'd3: sector_lut = img_sector3;
            default: sector_lut = img_sector0;
        endcase
    end
endfunction

function [1:0] next_buf_lut;
    input [1:0] cur_disp_buf;
    input       valid_now;
    begin
        if (!valid_now)
            next_buf_lut = 2'd0;                 // 首图固定写 buffer0
        else if (cur_disp_buf == 2'd0)
            next_buf_lut = 2'd1;
        else
            next_buf_lut = 2'd0;
    end
endfunction

always @(posedge clk or posedge rst) begin
    if (rst) begin
        wrfin_tgl_sync        <= 3'b000;
        scan_start_pulse      <= 1'b0;
        load_start_pulse      <= 1'b0;
        load_sector           <= 32'd0;
        scan_kicked           <= 1'b0;
        first_image_committed <= 1'b0;
        auto_play_en          <= 1'b0;
        auto_cnt              <= 32'd0;
        img_found_count       <= 3'd0;
        img_idx               <= 2'd0;
        load_idx              <= 2'd0;
        pending_buf_idx       <= 2'd0;
        write_buf_idx         <= 2'd0;
        disp_buf_idx          <= 2'd0;
        img_sector0           <= 32'd0;
        img_sector1           <= 32'd0;
        img_sector2           <= 32'd0;
        img_sector3           <= 32'd0;
        next_req_pending      <= 1'b0;
        home_req_pending      <= 1'b0;
        disp_req_pending      <= 1'b0;
        load_req_kind         <= 2'd0;
        load_busy             <= 1'b0;
        load_timeout_cnt      <= 32'd0;
        load_abort            <= 1'b0;
        source_done_seen      <= 1'b0;
        write_done_seen       <= 1'b0;
        display_valid         <= 1'b0;
    end else begin
        wrfin_tgl_sync   <= {wrfin_tgl_sync[1:0], write_finish_toggle};
        scan_start_pulse <= 1'b0;
        load_start_pulse <= 1'b0;
        load_abort       <= 1'b0;

        if (!sd_init_done) begin
            scan_kicked           <= 1'b0;
            first_image_committed <= 1'b0;
            auto_play_en          <= 1'b0;
            auto_cnt              <= 32'd0;
            img_found_count       <= 3'd0;
            img_idx               <= 2'd0;
            load_idx              <= 2'd0;
            pending_buf_idx       <= 2'd0;
            write_buf_idx         <= 2'd0;
            disp_buf_idx          <= 2'd0;
            img_sector0           <= 32'd0;
            img_sector1           <= 32'd0;
            img_sector2           <= 32'd0;
            img_sector3           <= 32'd0;
            next_req_pending      <= 1'b0;
            home_req_pending      <= 1'b0;
            disp_req_pending      <= 1'b0;
            load_req_kind         <= 2'd0;
            load_busy             <= 1'b0;
            load_timeout_cnt      <= 32'd0;
            load_abort            <= 1'b0;
            source_done_seen      <= 1'b0;
            write_done_seen       <= 1'b0;
            display_valid         <= 1'b0;
        end else begin
            // 扫描阶段缓存前 4 张图的起始 sector
            if (scan_found_valid) begin
                case (img_found_count)
                    3'd0: img_sector0 <= scan_found_sector;
                    3'd1: img_sector1 <= scan_found_sector;
                    3'd2: img_sector2 <= scan_found_sector;
                    3'd3: img_sector3 <= scan_found_sector;
                    default: ;
                endcase

                if (img_found_count < 3'd4)
                    img_found_count <= img_found_count + 3'd1;
            end

            // 记住 bmp_read 已经把源图送完 FIFO，但还不能切显示，得等整帧写完
            if (load_busy && bmp_ready)
                source_done_seen <= 1'b1;

            // 记住写帧完成脉冲，避免“先写完后源结束”导致脉冲丢失而卡死
            if (load_busy && write_finish_pulse)
                write_done_seen <= 1'b1;

            // 只有“源图送完 + 整帧写完”都满足，才提交新图并切换显示缓冲区
            if (load_busy && source_done_seen && write_done_seen) begin
                load_busy             <= 1'b0;
                load_timeout_cnt      <= 32'd0;
                source_done_seen      <= 1'b0;
                write_done_seen       <= 1'b0;
                disp_buf_idx          <= pending_buf_idx;
                img_idx               <= load_idx;
                display_valid         <= 1'b1;
                first_image_committed <= 1'b1;
                load_req_kind         <= 2'd0;
            end else if (load_busy) begin
                // 800x600（2813 扇区，CMD17 逐扇区读）加载最坏约 1.5s，
                // 1s 会误伤大图：超时→abort→重试死循环。放宽到 3s。
                if (load_timeout_cnt > 32'd300_000_000) begin
                    // 超时（例如读到坏图或截断的文件导致死锁），强制释放 busy；
                    // 被中止的跳转请求重挂起，下次自动重试，不再被吞掉
                    load_busy             <= 1'b0;
                    load_timeout_cnt      <= 32'd0;
                    source_done_seen      <= 1'b0;
                    write_done_seen       <= 1'b0;
                    load_abort            <= 1'b1;
                    case (load_req_kind)
                        2'd1: home_req_pending <= 1'b1;
                        2'd2: disp_req_pending <= 1'b1;
                        2'd3: next_req_pending <= 1'b1;
                        default: ;
                    endcase
                    load_req_kind         <= 2'd0;
                end else begin
                    load_timeout_cnt <= load_timeout_cnt + 32'd1;
                end
            end else begin
                load_timeout_cnt <= 32'd0;
            end

            // 上电后自动发起一次“扫描前 4 张 BMP”
            if (!scan_kicked && bmp_ready) begin
                scan_start_pulse      <= 1'b1;
                scan_kicked           <= 1'b1;
                first_image_committed <= 1'b0;
                auto_play_en          <= 1'b0;
                auto_cnt              <= 32'd0;
                img_found_count       <= 3'd0;
                img_idx               <= 2'd0;
                load_idx              <= 2'd0;
                pending_buf_idx       <= 2'd0;
                write_buf_idx         <= 2'd0;
                disp_buf_idx          <= 2'd0;
                next_req_pending      <= 1'b0;
                home_req_pending      <= 1'b0;
                load_req_kind         <= 2'd0;
                display_valid         <= 1'b0;
                load_busy             <= 1'b0;
                source_done_seen      <= 1'b0;
                write_done_seen       <= 1'b0;
            end else begin
                // 回主页跳转请求（顶层 ui_fsm 跨域而来）：不要求 scan_done，
                // 若请求先于扫描完成到达则先挂起，扫描完再派发
                if (home_req)
                    home_req_pending <= 1'b1;

                // 进入图片调节模式：显示第 2 张（调节对象）
                if (disp_req)
                    disp_req_pending <= 1'b1;

                // 忙的时候也只记 1 次“下一张”请求，不会累积成连跳两张
                if (key_next_press && scan_done && (img_found_count > 3'd0))
                    next_req_pending <= 1'b1;

                // 自动播放开/关
                if (key_auto_press && scan_done && (img_found_count > 3'd1)) begin
                    auto_play_en <= ~auto_play_en;
                    auto_cnt     <= 32'd0;
                end

                // 自动播放 1s 计数：只有当前没有写图任务时才计时；
                // 主页菜单模式暂停（否则轮播会把主页背景顶掉）
                if (scan_done && auto_play_en && display_valid && !load_busy && first_image_committed && (img_found_count > 3'd1) && !home_mode) begin
                    if (auto_tick)
                        auto_cnt <= 32'd0;
                    else
                        auto_cnt <= auto_cnt + 32'd1;
                end else begin
                    auto_cnt <= 32'd0;
                end

                // 首图自动加载到 buffer0（首图失败由 !first_image_committed 自然重试，kind=0）
                if (scan_done && !first_image_committed && bmp_ready && !load_busy && (img_found_count != 3'd0)) begin
                    load_idx         <= 2'd0;
                    load_sector      <= img_sector0;
                    pending_buf_idx  <= 2'd0;
                    write_buf_idx    <= 2'd0;
                    load_start_pulse <= 1'b1;
                    load_busy        <= 1'b1;
                    source_done_seen <= 1'b0;
                    write_done_seen  <= 1'b0;
                    next_req_pending <= 1'b0;
                    load_req_kind    <= 2'd0;
                    auto_cnt         <= 32'd0;
                end
                // 回到主页菜单：背景固定第一张图（从轮播图切回主页图）
                else if (scan_done && bmp_ready && display_valid && !load_busy && home_req_pending && (img_found_count != 3'd0)) begin
                    load_idx            <= 2'd0;
                    load_sector         <= img_sector0;
                    pending_buf_idx     <= next_buf_lut(disp_buf_idx, display_valid);
                    write_buf_idx       <= next_buf_lut(disp_buf_idx, display_valid);
                    load_start_pulse    <= 1'b1;
                    load_busy           <= 1'b1;
                    source_done_seen    <= 1'b0;
                    write_done_seen     <= 1'b0;
                    home_req_pending    <= 1'b0;
                    load_req_kind       <= 2'd1;
                    auto_cnt            <= 32'd0;
                end
                // 进入图片调节模式：显示第 2 张图
                else if (scan_done && bmp_ready && display_valid && !load_busy && disp_req_pending && (img_found_count > 3'd1)) begin
                    load_idx            <= 2'd1;
                    load_sector         <= sector_lut(2'd1);
                    pending_buf_idx     <= next_buf_lut(disp_buf_idx, display_valid);
                    write_buf_idx       <= next_buf_lut(disp_buf_idx, display_valid);
                    load_start_pulse    <= 1'b1;
                    load_busy           <= 1'b1;
                    source_done_seen    <= 1'b0;
                    write_done_seen     <= 1'b0;
                    disp_req_pending    <= 1'b0;
                    load_req_kind       <= 2'd2;
                    auto_cnt            <= 32'd0;
                end
                // 手动下一张优先：写到“非当前显示”的另一块 buffer
                else if (scan_done && bmp_ready && display_valid && !load_busy && next_req_pending && (img_found_count != 3'd0)) begin
                    load_idx         <= next_from_current;
                    load_sector      <= sector_lut(next_from_current);
                    pending_buf_idx  <= next_buf_lut(disp_buf_idx, display_valid);
                    write_buf_idx    <= next_buf_lut(disp_buf_idx, display_valid);
                    load_start_pulse <= 1'b1;
                    load_busy        <= 1'b1;
                    source_done_seen <= 1'b0;
                    write_done_seen  <= 1'b0;
                    next_req_pending <= 1'b0;
                    load_req_kind    <= 2'd3;
                    auto_cnt         <= 32'd0;
                end
                // 自动播放下一张：同样写到“非当前显示”的另一块 buffer
                // （自动失败由下一个 auto_tick 自然重试，kind=0）
                else if (scan_done && bmp_ready && display_valid && !load_busy && auto_play_en && auto_tick && (img_found_count > 3'd1)) begin
                    load_idx         <= next_from_current;
                    load_sector      <= sector_lut(next_from_current);
                    pending_buf_idx  <= next_buf_lut(disp_buf_idx, display_valid);
                    write_buf_idx    <= next_buf_lut(disp_buf_idx, display_valid);
                    load_start_pulse <= 1'b1;
                    load_busy        <= 1'b1;
                    source_done_seen <= 1'b0;
                    write_done_seen  <= 1'b0;
                    load_req_kind    <= 2'd0;
                    auto_cnt         <= 32'd0;
                end
            end
        end
    end
end

bmp_read bmp_read_m0(
    .clk                    (clk),
    .rst                    (rst),
    .ready                  (bmp_ready),

    .scan_start             (scan_start_pulse),
    .scan_start_sector      (SCAN_START_SECTOR),
    .scan_max_sector        (SCAN_MAX_SECTOR),
    .scan_target_count      (SCAN_TARGET_COUNT),
    .scan_done              (scan_done),
    .scan_found_valid       (scan_found_valid),
    .scan_found_sector      (scan_found_sector),
    .scan_found_total       (scan_found_total),

    .load_start             (load_start_pulse),
    .load_abort             (load_abort),
    .load_sector            (load_sector),

    .sd_init_done           (sd_init_done),
    .state_code             (state_code_i),
    .bmp_width              (bmp_width),
    .bmp_height             (bmp_height),
    .o_width                (bmp_read_o_width),
    .o_height               (bmp_read_o_height),
    .o_hdr_valid            (bmp_hdr_valid),
    .write_req              (write_req),
    .write_req_ack          (write_req_ack),
    .sd_sec_read            (sd_sec_read),
    .sd_sec_read_addr       (sd_sec_read_addr),
    .sd_sec_read_data       (sd_sec_read_data),
    .sd_sec_read_data_valid (sd_sec_read_data_valid),
    .sd_sec_read_end        (sd_sec_read_end),
    .bmp_data_wr_en         (bmp_data_wr_en),
    .bmp_data               (bmp_data)
);

sd_card_top sd_card_top_m0(
    .clk                    (clk),
    .rst                    (rst),
    .SD_nCS                 (SD_nCS),
    .SD_DCLK                (SD_DCLK),
    .SD_MOSI                (SD_MOSI),
    .SD_MISO                (SD_MISO),
    .sd_init_done           (sd_init_done),
    .sd_sec_read            (sd_sec_read),
    .sd_sec_read_addr       (sd_sec_read_addr),
    .sd_sec_read_data       (sd_sec_read_data),
    .sd_sec_read_data_valid (sd_sec_read_data_valid),
    .sd_sec_read_end        (sd_sec_read_end),
    .sd_sec_write           (1'b0),
    .sd_sec_write_addr      (32'd0),
    .sd_sec_write_data      (),
    .sd_sec_write_data_req  (),
    .sd_sec_write_end       ()
);

endmodule

module key_press_debounce #(
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer DEBOUNCE_MS = 20
)(
    input  wire clk,
    input  wire rst,
    input  wire button_in,    // 默认：松开=1，按下=0
    output reg  press_pulse
);

localparam integer DEBOUNCE_CYCLES = (CLK_FREQ_HZ / 1000) * DEBOUNCE_MS;

reg button_sync0;
reg button_sync1;
reg button_stable;
reg [31:0] cnt;

always @(posedge clk or posedge rst) begin
    if (rst) begin
        button_sync0  <= 1'b1;
        button_sync1  <= 1'b1;
        button_stable <= 1'b1;
        cnt           <= 32'd0;
        press_pulse   <= 1'b0;
    end else begin
        button_sync0 <= button_in;
        button_sync1 <= button_sync0;
        press_pulse  <= 1'b0;

        if (button_sync1 == button_stable) begin
            cnt <= 32'd0;
        end else begin
            if (cnt >= DEBOUNCE_CYCLES - 1) begin
                if (button_stable && !button_sync1)
                    press_pulse <= 1'b1;
                button_stable <= button_sync1;
                cnt           <= 32'd0;
            end else begin
                cnt <= cnt + 32'd1;
            end
        end
    end
end

endmodule
