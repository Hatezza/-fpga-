//=============================================================================
// i2s_test_tone_gen_single_pll_fix64 —— 内部合成旋律发生器（《欢乐颂》）
//
// 在原"固定 1kHz 测试音"基础上改造：
//   - 旋律：32 音符查表（每 0.5s 一个音符，Do..Si + 休止），循环播放 ≈16s
//   - 切歌：I_sel 变化时先播 GAP_NOTES 个休止符（默认 2 个 = 1s 无声停顿），
//     再从头播新旋律，便于分辨两首旋律的边界
//   - 包络：每个音符一个 Hann（升余弦）窗 = sin^2 包络，振幅从 0 慢慢增大、
//     再慢慢减小到 0；音符边界幅度为 0，杜绝切换"咔哒"破音
//   - 载波：沿用原 256 点正弦 LUT（幅度 ±2,000,000，轻柔音量），相位累加器
//     按音符频率步进（DDS）
//   - O_amp：0.1s 子窗口峰值（|样本| 高 16 位），每 0.1s 更新一次，供顶层 OSD
//     面板的 AMP 显示；数值随包络起伏（音符内 4800→14210→4800 扫动），
//     不再卡在单一音符峰值上
//
// I2S 帧格式与原版完全一致（不破坏 I2S_receiver / audio_arc_calculate ACR）：
//   每声道 64 BCLK，24bit 样本放 [63:40]；BCLK=6.25MHz，LRCK=48.83kHz
//=============================================================================
module i2s_test_tone_gen_single_pll_fix64 #(
    parameter integer SAMPLE_RATE = 48000,
    parameter integer SAMPLE_BITS = 24,
    parameter integer TONE_HZ     = 1000     // 兼容保留；本版为旋律模式，不再使用
)(
    input  wire       I_clk,      // video_clk 25MHz（内部 /2 使能等效 12.5MHz 节拍）
    input  wire       I_rst,
    output reg        O_i2s_BCLK, // 6.25MHz
    output reg        O_i2s_LRCK, // 48.83kHz
    output reg        O_i2s_DOUT, // 64bit slot，样本在 [63:40]
    output reg [15:0] O_amp,      // 幅值显示：0.1s 子窗口峰值（随包络起伏）
    input  wire       I_sel       // 旋律选择：0=欢乐颂，1=小星星（下个音符边界生效，先播 1s 无声停顿）
);

    localparam integer CHANNEL_BITS = 64;
    localparam integer FRAME_BITS   = 128;
    // 每音符时长：0.5s × 48828.125Hz = 24414 帧
    localparam integer NOTE_SAMPLES = 24414;
    // 切歌停顿：切换瞬间先播 GAP_NOTES 个休止符（×0.5s = 无声时长），
    // 方便耳朵分辨两首旋律的边界；默认 2 个 = 1s，改这里即可调长短
    localparam integer GAP_NOTES    = 2;
    // AMP 显示子窗口：0.1s × 48828.125Hz ≈ 4883 帧，每窗口输出一次峰值
    localparam integer SUB_WIN      = 4883;
    // 包络步进：2^24 / 24414 ≈ 687，env_idx = env_acc[23:17] 扫 0..127（1/2 正弦周期）
    localparam [23:0] ENV_STEP     = 24'd687;

    //----------------------------------------------------------------------
    // 正弦 LUT（256 点、24bit 有符号、幅度 ±2,000,000 ≈ -12dBFS，轻柔音量）
    //----------------------------------------------------------------------
    reg [23:0] pha_acc;
    reg signed [23:0] sine_lut [0:255];

    initial begin
        sine_lut[0] = 24'sh000000;
        sine_lut[1] = 24'sh00BFBA;
        sine_lut[2] = 24'sh017F57;
        sine_lut[3] = 24'sh023EB9;
        sine_lut[4] = 24'sh02FDC2;
        sine_lut[5] = 24'sh03BC55;
        sine_lut[6] = 24'sh047A55;
        sine_lut[7] = 24'sh0537A4;
        sine_lut[8] = 24'sh05F425;
        sine_lut[9] = 24'sh06AFBA;
        sine_lut[10] = 24'sh076A48;
        sine_lut[11] = 24'sh0823B2;
        sine_lut[12] = 24'sh08DBD9;
        sine_lut[13] = 24'sh0992A3;
        sine_lut[14] = 24'sh0A47F4;
        sine_lut[15] = 24'sh0AFBAE;
        sine_lut[16] = 24'sh0BADB7;
        sine_lut[17] = 24'sh0C5DF3;
        sine_lut[18] = 24'sh0D0C46;
        sine_lut[19] = 24'sh0DB897;
        sine_lut[20] = 24'sh0E62C9;
        sine_lut[21] = 24'sh0F0AC4;
        sine_lut[22] = 24'sh0FB06D;
        sine_lut[23] = 24'sh1053AB;
        sine_lut[24] = 24'sh10F464;
        sine_lut[25] = 24'sh119280;
        sine_lut[26] = 24'sh122DE7;
        sine_lut[27] = 24'sh12C67F;
        sine_lut[28] = 24'sh135C33;
        sine_lut[29] = 24'sh13EEEA;
        sine_lut[30] = 24'sh147E8E;
        sine_lut[31] = 24'sh150B09;
        sine_lut[32] = 24'sh159446;
        sine_lut[33] = 24'sh161A2E;
        sine_lut[34] = 24'sh169CAE;
        sine_lut[35] = 24'sh171BB2;
        sine_lut[36] = 24'sh179725;
        sine_lut[37] = 24'sh180EF5;
        sine_lut[38] = 24'sh18830F;
        sine_lut[39] = 24'sh18F362;
        sine_lut[40] = 24'sh195FDB;
        sine_lut[41] = 24'sh19C86B;
        sine_lut[42] = 24'sh1A2D01;
        sine_lut[43] = 24'sh1A8D8E;
        sine_lut[44] = 24'sh1AEA03;
        sine_lut[45] = 24'sh1B4251;
        sine_lut[46] = 24'sh1B966B;
        sine_lut[47] = 24'sh1BE644;
        sine_lut[48] = 24'sh1C31CF;
        sine_lut[49] = 24'sh1C7902;
        sine_lut[50] = 24'sh1CBBD0;
        sine_lut[51] = 24'sh1CFA30;
        sine_lut[52] = 24'sh1D3419;
        sine_lut[53] = 24'sh1D6980;
        sine_lut[54] = 24'sh1D9A5F;
        sine_lut[55] = 24'sh1DC6AC;
        sine_lut[56] = 24'sh1DEE63;
        sine_lut[57] = 24'sh1E117B;
        sine_lut[58] = 24'sh1E2FF1;
        sine_lut[59] = 24'sh1E49BF;
        sine_lut[60] = 24'sh1E5EE1;
        sine_lut[61] = 24'sh1E6F55;
        sine_lut[62] = 24'sh1E7B17;
        sine_lut[63] = 24'sh1E8226;
        sine_lut[64] = 24'sh1E8480;
        sine_lut[65] = 24'sh1E8226;
        sine_lut[66] = 24'sh1E7B17;
        sine_lut[67] = 24'sh1E6F55;
        sine_lut[68] = 24'sh1E5EE1;
        sine_lut[69] = 24'sh1E49BF;
        sine_lut[70] = 24'sh1E2FF1;
        sine_lut[71] = 24'sh1E117B;
        sine_lut[72] = 24'sh1DEE63;
        sine_lut[73] = 24'sh1DC6AC;
        sine_lut[74] = 24'sh1D9A5F;
        sine_lut[75] = 24'sh1D6980;
        sine_lut[76] = 24'sh1D3419;
        sine_lut[77] = 24'sh1CFA30;
        sine_lut[78] = 24'sh1CBBD0;
        sine_lut[79] = 24'sh1C7902;
        sine_lut[80] = 24'sh1C31CF;
        sine_lut[81] = 24'sh1BE644;
        sine_lut[82] = 24'sh1B966B;
        sine_lut[83] = 24'sh1B4251;
        sine_lut[84] = 24'sh1AEA03;
        sine_lut[85] = 24'sh1A8D8E;
        sine_lut[86] = 24'sh1A2D01;
        sine_lut[87] = 24'sh19C86B;
        sine_lut[88] = 24'sh195FDB;
        sine_lut[89] = 24'sh18F362;
        sine_lut[90] = 24'sh18830F;
        sine_lut[91] = 24'sh180EF5;
        sine_lut[92] = 24'sh179725;
        sine_lut[93] = 24'sh171BB2;
        sine_lut[94] = 24'sh169CAE;
        sine_lut[95] = 24'sh161A2E;
        sine_lut[96] = 24'sh159446;
        sine_lut[97] = 24'sh150B09;
        sine_lut[98] = 24'sh147E8E;
        sine_lut[99] = 24'sh13EEEA;
        sine_lut[100] = 24'sh135C33;
        sine_lut[101] = 24'sh12C67F;
        sine_lut[102] = 24'sh122DE7;
        sine_lut[103] = 24'sh119280;
        sine_lut[104] = 24'sh10F464;
        sine_lut[105] = 24'sh1053AB;
        sine_lut[106] = 24'sh0FB06D;
        sine_lut[107] = 24'sh0F0AC4;
        sine_lut[108] = 24'sh0E62C9;
        sine_lut[109] = 24'sh0DB897;
        sine_lut[110] = 24'sh0D0C46;
        sine_lut[111] = 24'sh0C5DF3;
        sine_lut[112] = 24'sh0BADB7;
        sine_lut[113] = 24'sh0AFBAE;
        sine_lut[114] = 24'sh0A47F4;
        sine_lut[115] = 24'sh0992A3;
        sine_lut[116] = 24'sh08DBD9;
        sine_lut[117] = 24'sh0823B2;
        sine_lut[118] = 24'sh076A48;
        sine_lut[119] = 24'sh06AFBA;
        sine_lut[120] = 24'sh05F425;
        sine_lut[121] = 24'sh0537A4;
        sine_lut[122] = 24'sh047A55;
        sine_lut[123] = 24'sh03BC55;
        sine_lut[124] = 24'sh02FDC2;
        sine_lut[125] = 24'sh023EB9;
        sine_lut[126] = 24'sh017F57;
        sine_lut[127] = 24'sh00BFBA;
        sine_lut[128] = 24'sh000000;
        sine_lut[129] = 24'shFF4046;
        sine_lut[130] = 24'shFE80A9;
        sine_lut[131] = 24'shFDC147;
        sine_lut[132] = 24'shFD023E;
        sine_lut[133] = 24'shFC43AB;
        sine_lut[134] = 24'shFB85AB;
        sine_lut[135] = 24'shFAC85C;
        sine_lut[136] = 24'shFA0BDB;
        sine_lut[137] = 24'shF95046;
        sine_lut[138] = 24'shF895B8;
        sine_lut[139] = 24'shF7DC4E;
        sine_lut[140] = 24'shF72427;
        sine_lut[141] = 24'shF66D5D;
        sine_lut[142] = 24'shF5B80C;
        sine_lut[143] = 24'shF50452;
        sine_lut[144] = 24'shF45249;
        sine_lut[145] = 24'shF3A20D;
        sine_lut[146] = 24'shF2F3BA;
        sine_lut[147] = 24'shF24769;
        sine_lut[148] = 24'shF19D37;
        sine_lut[149] = 24'shF0F53C;
        sine_lut[150] = 24'shF04F93;
        sine_lut[151] = 24'shEFAC55;
        sine_lut[152] = 24'shEF0B9C;
        sine_lut[153] = 24'shEE6D80;
        sine_lut[154] = 24'shEDD219;
        sine_lut[155] = 24'shED3981;
        sine_lut[156] = 24'shECA3CD;
        sine_lut[157] = 24'shEC1116;
        sine_lut[158] = 24'shEB8172;
        sine_lut[159] = 24'shEAF4F7;
        sine_lut[160] = 24'shEA6BBA;
        sine_lut[161] = 24'shE9E5D2;
        sine_lut[162] = 24'shE96352;
        sine_lut[163] = 24'shE8E44E;
        sine_lut[164] = 24'shE868DB;
        sine_lut[165] = 24'shE7F10B;
        sine_lut[166] = 24'shE77CF1;
        sine_lut[167] = 24'shE70C9E;
        sine_lut[168] = 24'shE6A025;
        sine_lut[169] = 24'shE63795;
        sine_lut[170] = 24'shE5D2FF;
        sine_lut[171] = 24'shE57272;
        sine_lut[172] = 24'shE515FD;
        sine_lut[173] = 24'shE4BDAF;
        sine_lut[174] = 24'shE46995;
        sine_lut[175] = 24'shE419BC;
        sine_lut[176] = 24'shE3CE31;
        sine_lut[177] = 24'shE386FE;
        sine_lut[178] = 24'shE34430;
        sine_lut[179] = 24'shE305D0;
        sine_lut[180] = 24'shE2CBE7;
        sine_lut[181] = 24'shE29680;
        sine_lut[182] = 24'shE265A1;
        sine_lut[183] = 24'shE23954;
        sine_lut[184] = 24'shE2119D;
        sine_lut[185] = 24'shE1EE85;
        sine_lut[186] = 24'shE1D00F;
        sine_lut[187] = 24'shE1B641;
        sine_lut[188] = 24'shE1A11F;
        sine_lut[189] = 24'shE190AB;
        sine_lut[190] = 24'shE184E9;
        sine_lut[191] = 24'shE17DDA;
        sine_lut[192] = 24'shE17B80;
        sine_lut[193] = 24'shE17DDA;
        sine_lut[194] = 24'shE184E9;
        sine_lut[195] = 24'shE190AB;
        sine_lut[196] = 24'shE1A11F;
        sine_lut[197] = 24'shE1B641;
        sine_lut[198] = 24'shE1D00F;
        sine_lut[199] = 24'shE1EE85;
        sine_lut[200] = 24'shE2119D;
        sine_lut[201] = 24'shE23954;
        sine_lut[202] = 24'shE265A1;
        sine_lut[203] = 24'shE29680;
        sine_lut[204] = 24'shE2CBE7;
        sine_lut[205] = 24'shE305D0;
        sine_lut[206] = 24'shE34430;
        sine_lut[207] = 24'shE386FE;
        sine_lut[208] = 24'shE3CE31;
        sine_lut[209] = 24'shE419BC;
        sine_lut[210] = 24'shE46995;
        sine_lut[211] = 24'shE4BDAF;
        sine_lut[212] = 24'shE515FD;
        sine_lut[213] = 24'shE57272;
        sine_lut[214] = 24'shE5D2FF;
        sine_lut[215] = 24'shE63795;
        sine_lut[216] = 24'shE6A025;
        sine_lut[217] = 24'shE70C9E;
        sine_lut[218] = 24'shE77CF1;
        sine_lut[219] = 24'shE7F10B;
        sine_lut[220] = 24'shE868DB;
        sine_lut[221] = 24'shE8E44E;
        sine_lut[222] = 24'shE96352;
        sine_lut[223] = 24'shE9E5D2;
        sine_lut[224] = 24'shEA6BBA;
        sine_lut[225] = 24'shEAF4F7;
        sine_lut[226] = 24'shEB8172;
        sine_lut[227] = 24'shEC1116;
        sine_lut[228] = 24'shECA3CD;
        sine_lut[229] = 24'shED3981;
        sine_lut[230] = 24'shEDD219;
        sine_lut[231] = 24'shEE6D80;
        sine_lut[232] = 24'shEF0B9C;
        sine_lut[233] = 24'shEFAC55;
        sine_lut[234] = 24'shF04F93;
        sine_lut[235] = 24'shF0F53C;
        sine_lut[236] = 24'shF19D37;
        sine_lut[237] = 24'shF24769;
        sine_lut[238] = 24'shF2F3BA;
        sine_lut[239] = 24'shF3A20D;
        sine_lut[240] = 24'shF45249;
        sine_lut[241] = 24'shF50452;
        sine_lut[242] = 24'shF5B80C;
        sine_lut[243] = 24'shF66D5D;
        sine_lut[244] = 24'shF72427;
        sine_lut[245] = 24'shF7DC4E;
        sine_lut[246] = 24'shF895B8;
        sine_lut[247] = 24'shF95046;
        sine_lut[248] = 24'shFA0BDB;
        sine_lut[249] = 24'shFAC85C;
        sine_lut[250] = 24'shFB85AB;
        sine_lut[251] = 24'shFC43AB;
        sine_lut[252] = 24'shFD023E;
        sine_lut[253] = 24'shFDC147;
        sine_lut[254] = 24'shFE80A9;
        sine_lut[255] = 24'shFF4046;
    end

    //----------------------------------------------------------------------
    // 音符 → 相位步进（2^24 相位累加 @ 48.83kHz；0 = 休止）
    //----------------------------------------------------------------------
    function [23:0] note_phase_step;
        input [3:0] note;
        begin
            case (note)
                4'd0: note_phase_step = 24'd89895;    // C4 261.63Hz
                4'd1: note_phase_step = 24'd100901;   // D4 293.66Hz
                4'd2: note_phase_step = 24'd113260;   // E4 329.63Hz
                4'd3: note_phase_step = 24'd119995;   // F4 349.23Hz
                4'd4: note_phase_step = 24'd134690;   // G4 392.00Hz
                4'd5: note_phase_step = 24'd151183;   // A4 440.00Hz
                4'd6: note_phase_step = 24'd169696;   // B4 493.88Hz
                4'd7: note_phase_step = 24'd179787;   // C5 523.25Hz
                default: note_phase_step = 24'd0;     // 休止
            endcase
        end
    endfunction

    //----------------------------------------------------------------------
    // 《欢乐颂》旋律表：32 音符 × 0.5s ≈ 16s 循环（0=C4..7=C5, 8=休止）
    //   E E F G | G F E D | C C D E | E D D ~ |
    //   E E F G | G F E D | C C D E | D C C ~ |
    //----------------------------------------------------------------------
    function [3:0] melody_note;
        input [5:0] idx;
        input       sel;
        begin
            if (sel) begin
                // 小星星：42 音符（C C G G A A G | F F E E D D C ...）
                case (idx)
                    6'd0:  melody_note = 4'd0;
                    6'd1:  melody_note = 4'd0;
                    6'd2:  melody_note = 4'd4;
                    6'd3:  melody_note = 4'd4;
                    6'd4:  melody_note = 4'd5;
                    6'd5:  melody_note = 4'd5;
                    6'd6:  melody_note = 4'd4;
                    6'd7:  melody_note = 4'd3;
                    6'd8:  melody_note = 4'd3;
                    6'd9:  melody_note = 4'd2;
                    6'd10: melody_note = 4'd2;
                    6'd11: melody_note = 4'd1;
                    6'd12: melody_note = 4'd1;
                    6'd13: melody_note = 4'd0;
                    6'd14: melody_note = 4'd4;
                    6'd15: melody_note = 4'd4;
                    6'd16: melody_note = 4'd3;
                    6'd17: melody_note = 4'd3;
                    6'd18: melody_note = 4'd2;
                    6'd19: melody_note = 4'd2;
                    6'd20: melody_note = 4'd1;
                    6'd21: melody_note = 4'd4;
                    6'd22: melody_note = 4'd4;
                    6'd23: melody_note = 4'd3;
                    6'd24: melody_note = 4'd3;
                    6'd25: melody_note = 4'd2;
                    6'd26: melody_note = 4'd2;
                    6'd27: melody_note = 4'd1;
                    6'd28: melody_note = 4'd0;
                    6'd29: melody_note = 4'd0;
                    6'd30: melody_note = 4'd4;
                    6'd31: melody_note = 4'd4;
                    6'd32: melody_note = 4'd5;
                    6'd33: melody_note = 4'd5;
                    6'd34: melody_note = 4'd4;
                    6'd35: melody_note = 4'd3;
                    6'd36: melody_note = 4'd3;
                    6'd37: melody_note = 4'd2;
                    6'd38: melody_note = 4'd2;
                    6'd39: melody_note = 4'd1;
                    6'd40: melody_note = 4'd1;
                    6'd41: melody_note = 4'd0;
                    default: melody_note = 4'd8;
                endcase
            end else begin
                // 欢乐颂：32 音符
                case (idx)
                6'd0:  melody_note = 4'd2;   // E
                6'd1:  melody_note = 4'd2;   // E
                6'd2:  melody_note = 4'd3;   // F
                6'd3:  melody_note = 4'd4;   // G
                6'd4:  melody_note = 4'd4;   // G
                6'd5:  melody_note = 4'd3;   // F
                6'd6:  melody_note = 4'd2;   // E
                6'd7:  melody_note = 4'd1;   // D
                6'd8:  melody_note = 4'd0;   // C
                6'd9:  melody_note = 4'd0;   // C
                6'd10: melody_note = 4'd1;   // D
                6'd11: melody_note = 4'd2;   // E
                6'd12: melody_note = 4'd2;   // E
                6'd13: melody_note = 4'd1;   // D
                6'd14: melody_note = 4'd1;   // D
                6'd15: melody_note = 4'd8;   // 休止
                6'd16: melody_note = 4'd2;   // E
                6'd17: melody_note = 4'd2;   // E
                6'd18: melody_note = 4'd3;   // F
                6'd19: melody_note = 4'd4;   // G
                6'd20: melody_note = 4'd4;   // G
                6'd21: melody_note = 4'd3;   // F
                6'd22: melody_note = 4'd2;   // E
                6'd23: melody_note = 4'd1;   // D
                6'd24: melody_note = 4'd0;   // C
                6'd25: melody_note = 4'd0;   // C
                6'd26: melody_note = 4'd1;   // D
                6'd27: melody_note = 4'd2;   // E
                6'd28: melody_note = 4'd1;   // D
                6'd29: melody_note = 4'd0;   // C
                6'd30: melody_note = 4'd0;   // C
                default: melody_note = 4'd8; // 休止
                endcase
            end
        end
    endfunction

    //----------------------------------------------------------------------
    // 旋律 / 包络 / 乘法流水状态
    //----------------------------------------------------------------------
    reg        mclk_en;   // 12.5MHz 有效使能（每 2 拍 1）
    reg [6:0]  bit_cnt;
    reg [63:0] left_word;
    reg [63:0] right_word;

    reg [5:0]  melody_idx;      // 当前音符序号 0..63
    reg        sel_cur;        // 当前生效的旋律选择（切换在下个音符边界生效）
    reg [2:0]  gap_cnt;        // 切歌无声停顿计数（剩余休止符个数，0=不在停顿）
    wire       sel_new = (sel_cur != I_sel);
    // 停顿中保持 0；停顿结束（gap_cnt==1 那拍）也从 0 起播新旋律
    wire [5:0] next_idx = (gap_cnt != 3'd0) ? 6'd0 :
                          sel_new ? 6'd0 :
                          (sel_cur ? ((melody_idx == 6'd41) ? 6'd0 : melody_idx + 6'd1)
                                   : ((melody_idx == 6'd31) ? 6'd0 : melody_idx + 6'd1));
    reg [14:0] note_cnt;        // 当前音符内帧计数 0..24413
    reg [12:0] sub_cnt;         // 0.1s 子窗口内帧计数 0..SUB_WIN-1（AMP 显示用）
    reg [23:0] step_cur;        // 当前音符相位步进（0 = 休止）
    reg [23:0] env_acc;         // 包络相位累加（24 位）
    wire [6:0] env_idx = env_acc[23:17];   // 0..127，扫 1/2 正弦周期

    reg        env_pending;     // 帧尾已锁存载波，等待下一 tick 锁存包络
    reg [2:0]  pipe_cnt;        // 帧尾后的流水稳定计数（峰值比较门控）

    // 两级流水乘法：sample = sin * (env^2 >> 21) >> 21 = sin*env^2 / 2^42
    reg signed [23:0] sin_a;
    reg signed [23:0] env_a;
    reg signed [26:0] p1;
    reg signed [23:0] sample_cur;

    wire signed [47:0] m1_raw = sin_a * env_a;
    wire signed [50:0] m2_raw = p1    * env_a;

    reg [15:0] amp_peak;        // 当前音符峰值（显示用）
    wire [15:0] amp_cur = sample_cur[23] ? (~sample_cur[22:7] + 16'd1)
                                         :  sample_cur[22:7];

    always @(posedge I_clk or posedge I_rst) begin
        if (I_rst) begin
            mclk_en     <= 1'b0;
            O_i2s_BCLK  <= 1'b0;
            O_i2s_LRCK  <= 1'b0;
            O_i2s_DOUT  <= 1'b0;
            bit_cnt     <= 7'd0;
            pha_acc     <= 24'd0;
            left_word   <= {24'sd0, 40'd0};
            right_word  <= {24'sd0, 40'd0};
            melody_idx  <= 6'd0;
            sel_cur     <= 1'b0;
            gap_cnt     <= 3'd0;
            note_cnt    <= 16'd0;
            sub_cnt     <= 13'd0;
            step_cur    <= note_phase_step(4'd2);   // 起始音符 E4
            env_acc     <= 24'd0;
            env_pending <= 1'b0;
            pipe_cnt    <= 3'd0;
            sin_a       <= 24'sd0;
            env_a       <= 24'sd0;
            p1          <= 27'sd0;
            sample_cur  <= 24'sd0;
            amp_peak    <= 16'd0;
            O_amp       <= 16'd0;
        end else begin
            mclk_en <= ~mclk_en;

            // 乘法流水（sin_a/env_a 整帧保持，每拍重算收敛）
            p1         <= m1_raw >>> 21;
            sample_cur <= m2_raw >>> 21;
            // 峰值比较只在流水稳定后（帧尾 +4 拍之后）进行，避开换音符瞬间的中间值
            if (pipe_cnt >= 3'd4)
                amp_peak <= (amp_cur > amp_peak) ? amp_cur : amp_peak;
            if (pipe_cnt != 3'd7)
                pipe_cnt <= pipe_cnt + 3'd1;

            if (mclk_en) begin
                // 有效 tick：BCLK 翻转一次 => BCLK = 12.5MHz / 2
                // 帧尾后的第一个 tick 补锁包络样本（LUT 单读端口分时复用）
                if (env_pending) begin
                    env_a       <= sine_lut[env_idx];
                    env_pending <= 1'b0;
                end

                // 在 BCLK 下降沿更新 LRCK 和 DOUT，供接收端在 BCLK 上升沿采样
                if (O_i2s_BCLK == 1'b1) begin
                    if (bit_cnt < 7'd63) begin
                        O_i2s_LRCK <= 1'b0;
                        O_i2s_DOUT <= left_word[63];
                        left_word  <= {left_word[62:0], 1'b0};
                        bit_cnt    <= bit_cnt + 7'd1;
                    end else if (bit_cnt == 7'd63) begin
                        O_i2s_LRCK <= 1'b1;
                        O_i2s_DOUT <= left_word[63];
                        left_word  <= {left_word[62:0], 1'b0};
                        bit_cnt    <= 7'd64;
                    end else if (bit_cnt < 7'd127) begin
                        O_i2s_LRCK <= 1'b1;
                        O_i2s_DOUT <= right_word[63];
                        right_word <= {right_word[62:0], 1'b0};
                        bit_cnt    <= bit_cnt + 7'd1;
                    end else begin
                        O_i2s_LRCK <= 1'b0;
                        O_i2s_DOUT <= right_word[63];
                        bit_cnt    <= 7'd0;
                        pipe_cnt   <= 3'd0;

                        // ---- 帧尾：锁存载波、推进相位 ----
                        pha_acc    <= pha_acc + step_cur;
                        sin_a      <= (step_cur == 24'd0) ? 24'sd0
                                                          : sine_lut[pha_acc[23:16]];
                        env_pending <= 1'b1;

                        // ---- 音符切换（每 0.5s）----
                        if (note_cnt == NOTE_SAMPLES - 1) begin
                            note_cnt   <= 16'd0;
                            sub_cnt    <= 13'd0;
                            melody_idx <= next_idx;
                            if (sel_new) begin
                                // 切歌：先插 GAP_NOTES 个休止符（无声停顿），再从头播新旋律
                                sel_cur <= I_sel;
                                gap_cnt <= GAP_NOTES;
                            end else if (gap_cnt != 3'd0) begin
                                gap_cnt <= gap_cnt - 3'd1;
                            end
                            // 停顿拍（切换当拍 + gap_cnt>1 期间）输出休止符
                            if (sel_new || (gap_cnt > 3'd1))
                                step_cur <= 24'd0;
                            else
                                step_cur <= note_phase_step(melody_note(next_idx, I_sel));
                            env_acc    <= 24'd0;
                            O_amp      <= amp_peak;   // 显示幅值 0.5s 更新一次
                            amp_peak   <= 16'd0;
                        end else begin
                            note_cnt <= note_cnt + 16'd1;
                            env_acc  <= env_acc + ENV_STEP;
                            // AMP 显示每 0.1s 更新一次：输出本子窗口峰值并清零
                            //（最后一个子窗口由上方 note 切换分支在音符末尾输出）
                            if (sub_cnt == SUB_WIN - 1) begin
                                sub_cnt  <= 13'd0;
                                O_amp    <= amp_peak;
                                amp_peak <= 16'd0;
                            end else begin
                                sub_cnt <= sub_cnt + 13'd1;
                            end
                        end

                        // 装载下一帧样本（左右同值；流水两级延迟 = 恒定 1 帧滞后）
                        left_word  <= {sample_cur, 40'd0};
                        right_word <= {sample_cur, 40'd0};
                    end
                end

                O_i2s_BCLK <= ~O_i2s_BCLK;
            end
        end
    end

endmodule
