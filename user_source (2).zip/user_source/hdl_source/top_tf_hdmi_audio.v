module top(
    input                       clk,
    input                       rst_n,
    input                       key1,           // 手动下一张
    input                       key2,           // 自动播放 开/关
    input                       ir,             // 红外接收头 OUT（J1-17 = D16，光敏 J1-16 旁）

	output [5:0]                seg_sel,
	output [7:0]                seg_data,

    // HDMI TMDS
    output                      HDMI_CLK_P,
    output                      HDMI_D2_P,
    output                      HDMI_D1_P,
    output                      HDMI_D0_P,

    // HDMI DDC
    output                      HDMI_DDC_SCL,
    inout                       HDMI_DDC_SDA,

    // TF card SPI
    output                      sd_ncs,
    output                      sd_dclk,
    output                      sd_mosi,
    input                       sd_miso
);

parameter MEM_DATA_BITS = 32;
parameter ADDR_BITS     = 21;
parameter BUSRT_BITS    = 10;
parameter FRAME_PIXELS  = 24'd307200;   // 640*480
parameter BUF0_ADDR     = 24'd0;
parameter BUF1_ADDR     = FRAME_PIXELS;

wire Sdr_init_done;
wire Sdr_init_ref_vld;
wire Sdr_busy;

wire sd_card_clk;
wire ext_mem_clk;
wire ext_mem_clk_sft;
wire video_clk;
wire hdmi_5x_clk;

wire hs;
wire vs;
wire de;

wire [23:0] vout_data_raw;
wire [23:0] vout_data;
wire        display_valid;

wire [3:0]  state_code;
wire [6:0]  seg_data_0;

wire        video_read_req;
wire        video_read_req_ack;
wire        video_read_en;
wire [31:0] video_read_data;

wire        sd_card_write_en;
wire [31:0] sd_card_write_data;
wire        sd_card_write_req;
wire        sd_card_write_req_ack;
wire        frame_write_finish;
reg         frame_write_toggle_mem;

wire [1:0]  write_buf_idx;
wire [1:0]  disp_buf_idx;      // sd_card_bmp 原始硬切输出（新缓冲就绪）
wire [1:0]  img_buf_idx;       // img_effect 延迟后的生效缓冲 → frame_read_write
wire [23:0] img_rgb;           // img_effect 过渡+调参后的像素
wire        img_busy;          // img_effect 过渡进行中（可接 LED 观察）

wire App_rd_en;
wire [ADDR_BITS-1:0] App_rd_addr;
wire Sdr_rd_en;
wire [MEM_DATA_BITS-1:0] Sdr_rd_dout;
wire App_wr_en;
wire [ADDR_BITS-1:0] App_wr_addr;
wire [MEM_DATA_BITS-1:0] App_wr_din;
wire [3:0] App_wr_dm;

wire hs_0;
wire vs_0;
wire de_0;

wire [23:0] osd_rgb;
wire        osd_de;
wire        osd_hs;
wire        osd_vs;
wire        osd_on;      // 可选调试
// HDMI 1.4b 相关
wire        axis_s_user;
wire        axis_s_valid;
wire        axis_s_last;
wire [23:0] axis_s_data;
wire        axis_s_ready;

wire        edid_trig;
wire        edid_valid;
wire [7:0]  edid_data;

wire [9:0]  tmds_ch0_data;
wire [9:0]  tmds_ch1_data;
wire [9:0]  tmds_ch2_data;
wire [9:0]  tmds_clk_data;

// 统一复位：TF 图像链路 + HDMI 链路
wire sys_pll_lock;
wire video_pll_lock;
wire rst_all;

reg [19:0] rst_cnt = 20'd0;
reg rst_all_reg = 1'b1;

always @(posedge clk) begin
    if (!rst_n) begin
        rst_cnt <= 20'd0;
        rst_all_reg <= 1'b1;
    end else if (!rst_all_reg) begin
        // 一旦复位释放，忽略后续微小的 PLL 抖动，防止系统在使用时随机复位
        rst_all_reg <= 1'b0;
    end else if (sys_pll_lock && video_pll_lock) begin
        // 等待 PLL 连续稳定 2ms @ 50MHz（车载快启：lock 后尽快释放复位）
        if (rst_cnt < 20'd100_000) begin
            rst_cnt <= rst_cnt + 1'b1;
            rst_all_reg <= 1'b1;
        end else begin
            rst_all_reg <= 1'b0;
        end
    end else begin
        rst_cnt <= 20'd0;
        rst_all_reg <= 1'b1;
    end
end

assign rst_all = rst_all_reg;

// 保持你原来的 TF / SDRAM / video 时钟
sys_pll sys_pll_m0(
    .refclk     (clk),
    .reset      (1'b0),
    .extlock    (sys_pll_lock),

    .clk0_out   (sd_card_clk),
    .clk1_out   (ext_mem_clk),
    .clk2_out   (ext_mem_clk_sft)
);

video_pll video_pll_m0(
    .refclk     (clk),
    .reset      (1'b0),
    .extlock    (video_pll_lock),
    .clk0_out   (video_clk),
    .clk1_out   (hdmi_5x_clk)
);

// mem_clk 域把 write_finish 单拍转成 toggle，供 sd_card_clk 域可靠同步
always @(posedge ext_mem_clk or posedge rst_all) begin
    if (rst_all)
        frame_write_toggle_mem <= 1'b0;
    else if (frame_write_finish)
        frame_write_toggle_mem <= ~frame_write_toggle_mem;
end

// ===================== 按键去抖 + 菜单 UI（按模式分时复用） =====================
// ui_fsm 侧（video_clk 25MHz）单独去抖，产出单拍脉冲；
// sd_card_bmp 侧不在此去抖 —— 它内部已自带 key_press_debounce
// （sd_card_bmp.v:88-106，DEBOUNCE_MS=50），故这里只送原始引脚电平 + 模式门控。
wire k1_press, k2_press;                // video_clk 域：菜单光标 / 确认
wire [1:0] ui_mode, ui_cursor, ui_menu_sel;
wire       ui_menu_en, ui_key_gate;

key_press_debounce #(
    .CLK_FREQ_HZ (25_000_000),
    .DEBOUNCE_MS (20)
) u_key1_deb_menu (
    .clk        (video_clk),
    .rst        (rst_all),
    .button_in  (key1),
    .press_pulse(k1_press)
);

key_press_debounce #(
    .CLK_FREQ_HZ (25_000_000),
    .DEBOUNCE_MS (20)
) u_key2_deb_menu (
    .clk        (video_clk),
    .rst        (rst_all),
    .button_in  (key2),
    .press_pulse(k2_press)
);

// ===================== 放大模式长按 key2 >1s 返回菜单 =====================
// 为什么需要：进入放大模式后两个键都用于增减亮度，若没有返回路径会被"卡"住。
// 用原始引脚（低有效）而非 k2_press 脉冲 —— 单拍脉冲无法判断按压时长。
reg k2s0, k2s1;
always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) begin
        k2s0 <= 1'b1;          // 低有效，复位视为"松开"
        k2s1 <= 1'b1;
    end else begin
        k2s0 <= key2;
        k2s1 <= k2s0;          // 2 级同步
    end
end

localparam [24:0] LONG_PRESS_CNT = 25'd25_000_000;   // 1s @ 25MHz

reg [24:0] lp_cnt;
reg        lp_fired;

always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) begin
        lp_cnt   <= 25'd0;
        lp_fired <= 1'b0;
    end else if (k2s1) begin        // 松开：清零，允许下次再触发
        lp_cnt   <= 25'd0;
        lp_fired <= 1'b0;
    end else if (lp_cnt >= LONG_PRESS_CNT) begin
        lp_cnt   <= LONG_PRESS_CNT; // 饱和，停止计数
        lp_fired <= 1'b1;           // 达到 1s 后保持，直到松开
    end else begin
        lp_cnt   <= lp_cnt + 25'd1;
    end
end

// 取 lp_fired 的上升沿得到单拍脉冲；仅放大模式下放行
reg lp_fired_d;
always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) lp_fired_d <= 1'b0;
    else         lp_fired_d <= lp_fired;
end

// 长按 key2 >1s 返回菜单：任何非菜单模式（图片轮播/图片调节/频谱显示）都放行
wire ui_back_pulse = lp_fired & ~lp_fired_d & (ui_mode != 2'd0);

// ===================== 亮度/对比度参数 =====================
// 亮度：环境光自动（light_sensor 内部 ADC CH1），随光线明暗变化
// 对比度：放大模式下 key1/key2 手动调节
wire [7:0] cc_brightness;
wire [7:0] cc_contrast;
wire [7:0] light_bright;

assign cc_brightness = light_bright;
wire [15:0] img_src_w;    // sd_card_bmp 解析出的当前图片宽高（mode2 信息面板用）
wire [15:0] img_src_h;

// 放大模式的按键归 param_ctrl；其余模式 param_ctrl 收不到脉冲
// 红外功能脉冲：声明必须早于首次使用（下方 cc_key_* 与 u_ui_fsm 端口连接）。
// 若在使用后才声明，TD 会在端口连接处按隐式 1bit 网络另立新网（HDL-7225），
// 菜单侧接到无驱动网络恒为 0：数码管键值正常但菜单/功能全不响应。
wire ir_p44, ir_p40, ir_p43, ir_p09;   // 44=左移 40=右移 43=确认 09=返回菜单（左右已交换）

wire cc_key_up   = (k1_press | ir_p44) & (ui_mode == 2'd2);   // 44=对比度上升
wire cc_key_down = (k2_press | ir_p40) & (ui_mode == 2'd2);   // 40=对比度下降

ui_fsm #(
    .MENU_ITEMS (3)
) u_ui_fsm (
    .I_clk        (video_clk),
    .I_rst        (rst_all),
    .I_key1_press (k1_press | ir_p44),   // 44/key1=光标左移（左右已交换）
    .I_key_left   (ir_p40),              // 40=光标右移（左右已交换）
    .I_key2_press (k2_press | ir_p43),   // 43=确认
    .I_back       (ui_back_pulse | ir_p09),   // 09 或长按 key2 >1s 返回菜单
    .O_mode       (ui_mode),
    .O_cursor_y   (ui_cursor),
    .O_menu_en    (ui_menu_en),
    .O_menu_sel   (ui_menu_sel),
    .O_key_gate   (ui_key_gate)
);

// ===================== 参数控制 =====================
// 亮度已改为光敏自动（light_sensor 驱动 cc_brightness），
// param_ctrl 只负责对比度：I_sel 固定 1，I_default 未接
param_ctrl #(
    .BRIGHT_DEF   (8'd128),
    .CONTRAST_DEF (8'd128),
    .STEP         (8'd8)
) u_param_ctrl (
    .I_clk        (video_clk),
    .I_rst        (rst_all),
    .I_key_up     (cc_key_up),
    .I_key_down   (cc_key_down),
    .I_sel        (1'b1),
    .I_default    (1'b0),
    .O_brightness (),               // 亮度改由光敏传感器自动驱动
    .O_contrast   (cc_contrast)
);

// ===================== 环境光亮度采集（内部 ADC CH1，AO 直连） =====================
// 光敏模块 AO → J1 第 16 脚（M10 = ADC_CH_1）；光强越强 AO 越低时改 SENSOR_INVERT
light_sensor #(
    .SENSOR_INVERT (1'b0)
) u_light_sensor (
    .I_clk        (video_clk),
    .I_rst        (rst_all),
    .O_brightness (light_bright)
);

// ui_key_gate 跨到 sd_card_clk 域 + 退出菜单后的释放锁存
// rst_all 为单调静态电平，工程内各时钟域均直接用作异步复位
// 锁存目的：确认进入某模式时手指仍按着键，若立即撤掉屏蔽，sd_card_bmp
//          会在其 50ms 去抖后把这次"按下"当成新按键
//          （图片模式下表现为附带一次"自动播放 toggle"）。
// 需要屏蔽 sd_card_bmp 的场景：菜单模式（改光标）或放大模式（改亮度）。
// 两者都在 video_clk 域产生，跨到 sd_card_clk 域后统一作为 sd_key_gate 使用。
wire sd_key_block_src = ui_key_gate | (ui_mode == 2'd2);

localparam [24:0] KEY_GATE_HOLD_CNT = 25'd20_000_000;   // 200ms @ 100MHz

reg        gate_sync0, gate_sync1;
reg [24:0] gate_hold_cnt;
reg        sd_key_gate_r;

always @(posedge sd_card_clk or posedge rst_all) begin
    if (rst_all) begin
        gate_sync0    <= 1'b0;
        gate_sync1    <= 1'b0;
        gate_hold_cnt <= 25'd0;
        sd_key_gate_r <= 1'b1;          // 复位即菜单模式，屏蔽按键
    end else begin
        gate_sync0 <= sd_key_block_src; // 菜单或放大模式：屏蔽 sd_card_bmp
        gate_sync1 <= gate_sync0;       // 2 级同步，得到 sd_card_clk 域电平

        if (gate_sync1) begin
            gate_hold_cnt <= 25'd0;     // 处于菜单模式：立即屏蔽并清计数
            sd_key_gate_r <= 1'b1;
        end else if (gate_hold_cnt < KEY_GATE_HOLD_CNT) begin
            gate_hold_cnt <= gate_hold_cnt + 25'd1;   // 刚退出菜单：续屏蔽 200ms
            sd_key_gate_r <= 1'b1;
        end else begin
            sd_key_gate_r <= 1'b0;      // 释放，按键交还 sd_card_bmp
        end
    end
end
wire sd_key_gate = sd_key_gate_r;   // 1 = 屏蔽 sd_card_bmp 的按键

// sd_card_bmp 内部已自带去抖，故必须送"原始引脚电平"，不能送已去抖的单拍脉冲
// （顶层去抖脉冲仅 40ns，其内部要求电平稳定 50ms，根本看不到）。
// 屏蔽时置 1（=松开），不能置 0（=按下），否则进入菜单会误触发一次动作。
// 40/44 的虚拟电平（低有效、保持 180ms）：sd_card_bmp 内部 50ms 去抖要求电平输入。
// 声明放这里：下方 sd_key_next/sd_key_auto 先于驱动它的 always 块使用。
reg        ir_lvl40, ir_lvl44;
wire sd_key_next = sd_key_gate ? 1'b1 : (key1 & ir_lvl40);   // 40=手动下一张
wire sd_key_auto = sd_key_gate ? 1'b1 : (key2 & ir_lvl44);   // 44=轮播开/关

// ===================== 主页背景：回菜单命令 =====================
// ui_mode 在 video_clk 域，sd_card_bmp 在 sd_card_clk 域。模式跳转是慢速事件：
// video_clk 域检测跳转 → toggle → sd_card_clk 域 2 级同步 → 双边沿检测还原单拍脉冲；
// home_mode 为电平信号，2 级同步后直送。
//   home_req  : 任意模式回到菜单 → sd_card_bmp 重新加载第一张图（主页背景）
//   home_mode : 菜单模式电平 → sd_card_bmp 暂停自动轮播（防止顶掉主页背景）
reg [1:0] ui_mode_d;
always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) ui_mode_d <= 2'd0;
    else         ui_mode_d <= ui_mode;
end

wire home_vclk = (ui_mode == 2'd0) && (ui_mode_d != 2'd0);   // 任意模式 → 菜单

reg home_tgl;
always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) home_tgl <= 1'b0;
    else if (home_vclk) home_tgl <= ~home_tgl;
end

reg [2:0] home_sync;
always @(posedge sd_card_clk or posedge rst_all) begin
    if (rst_all) home_sync <= 3'd0;
    else         home_sync <= {home_sync[1:0], home_tgl};
end
wire sd_home_req = home_sync[2] ^ home_sync[1];

// 进入图片调节模式（菜单 → mode2）：显示第 2 张图（调节对象），
// 与 home_req 同款 toggle + 2FF + 边沿还原 CDC
wire disp_vclk = (ui_mode == 2'd2) && (ui_mode_d != 2'd2);

reg disp_tgl;
always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) disp_tgl <= 1'b0;
    else if (disp_vclk) disp_tgl <= ~disp_tgl;
end

reg [2:0] disp_sync;
always @(posedge sd_card_clk or posedge rst_all) begin
    if (rst_all) disp_sync <= 3'd0;
    else         disp_sync <= {disp_sync[1:0], disp_tgl};
end
wire sd_disp_req = disp_sync[2] ^ disp_sync[1];

reg [1:0] home_mode_sync;
always @(posedge sd_card_clk or posedge rst_all) begin
    if (rst_all) home_mode_sync <= 2'b11;    // 复位即暂停自动轮播
    else         home_mode_sync <= {home_mode_sync[0], (ui_mode != 2'd1)};
end
wire sd_home_mode = home_mode_sync[1];       // 只有 Mode1（图片轮播）允许自动播放；菜单/调节/频谱全部暂停

// ===================== TF 多图扫描与缓存（双缓冲） =====================
wire [2:0] found_count;   // 扫描到的图片数（sd_card_clk 域，数码管诊断显示）

sd_card_bmp #(
    .CLK_FREQ_HZ       (100_000_000),
    .SCAN_START_SECTOR (32'd0),
    .SCAN_MAX_SECTOR   (32'd131071),  // 64MB：快扫(簇网格)可达全范围；exFAT 全扫会较慢
    .SCAN_TARGET_COUNT (3'd4)
) sd_card_bmp_m0(
    .clk               (sd_card_clk),
    .rst               (rst_all),
    .key_next          (sd_key_next),
    .key_auto          (sd_key_auto),
    .home_req          (sd_home_req),
    .home_mode         (sd_home_mode),
    .disp_req          (sd_disp_req),
    .o_found_count     (found_count),
    .state_code        (state_code),
    .bmp_width         (16'd640),
    .bmp_height        (16'd480),
    .o_src_width       (img_src_w),
    .o_src_height      (img_src_h),
    .display_valid     (display_valid),

    .write_finish_toggle(frame_write_toggle_mem),
    .write_buf_idx     (write_buf_idx),
    .disp_buf_idx      (disp_buf_idx),

    .write_req         (sd_card_write_req),
    .write_req_ack     (sd_card_write_req_ack),
    .write_en          (sd_card_write_en),
    .write_data        (sd_card_write_data),
    .SD_nCS            (sd_ncs),
    .SD_DCLK           (sd_dclk),
    .SD_MOSI           (sd_mosi),
    .SD_MISO           (sd_miso)
);

seg_decoder seg_decoder_m0(
    .bin_data          (state_code),
    .seg_data          (seg_data_0)
);

// ===================== 数码管显示亮度参数 =====================
// cc_brightness 在 video_clk 域，seg_scan 在 clk 域 → 2 级同步器
// （该值只在按键时更新，变化极慢，2FF 足够；切换瞬间可能显示一帧中间值，可接受）
reg [7:0] ccb_sync0, ccb_sync1;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        ccb_sync0 <= 8'd0;
        ccb_sync1 <= 8'd0;
    end else begin
        ccb_sync0 <= cc_brightness;
        ccb_sync1 <= ccb_sync0;
    end
end

// ===================== 数码管显示扫描到的图片数（诊断） =====================
// found_count 在 sd_card_clk 域（100MHz），seg_scan 在 clk 域（50MHz），
// 扫描完成后恒定，2 级同步足够。左起第 2 位显示：如 "2"=找到 2 张图。
// 用途：快速区分"卡上只有 1 张图/扫描漏检"与"轮播逻辑问题"。
reg [2:0] fnd_sync0, fnd_sync1;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        fnd_sync0 <= 3'd0;
        fnd_sync1 <= 3'd0;
    end else begin
        fnd_sync0 <= found_count;
        fnd_sync1 <= fnd_sync0;
    end
end

wire [6:0] seg_fnd;
seg_decoder seg_fnd_m0 (
    .bin_data(fnd_sync1),
    .seg_data(seg_fnd)
);

// 8bit 二进制 → 3 位 BCD（双 dable「加 3 移位」），纯组合无除法。
// 已用 iverilog 对全部 256 个输入值逐一比对验证通过。
function [11:0] bin2bcd;
    input [7:0] b;
    integer i;
    reg [11:0] acc;
    begin
        acc = 12'd0;
        for (i = 7; i >= 0; i = i - 1) begin
            if (acc[3:0]  >= 4'd5) acc[3:0]  = acc[3:0]  + 4'd3;
            if (acc[7:4]  >= 4'd5) acc[7:4]  = acc[7:4]  + 4'd3;
            if (acc[11:8] >= 4'd5) acc[11:8] = acc[11:8] + 4'd3;
            acc = {acc[10:0], b[i]};
        end
        bin2bcd = acc;
    end
endfunction

wire [11:0] ccb_bcd = bin2bcd(ccb_sync1);

wire [6:0] seg_ccb_h, seg_ccb_t, seg_ccb_u;

seg_decoder seg_ccb_hund (.bin_data(ccb_bcd[11:8]), .seg_data(seg_ccb_h));
seg_decoder seg_ccb_tens (.bin_data(ccb_bcd[7:4]),  .seg_data(seg_ccb_t));
seg_decoder seg_ccb_unit (.bin_data(ccb_bcd[3:0]),  .seg_data(seg_ccb_u));

// ===================== 红外遥控解码（盲测版：左两位数码管显示键值） =====================
wire [7:0] ir_cmd;
wire       ir_valid;
// 红外键值解码脉冲（video_clk 域）：44 40 43 09 四键
// 实测键值：右=64 左=60 确认=63 返回=29（与文档遥控器不同型号，以实测为准）
// 注意：解码器同拍更新 ir_cmd 和 ir_valid（非阻塞），valid 当拍读 ir_cmd 是旧值，
// 必须用 valid 后一拍 + 保持寄存器（ir_cmd_hold）比较，否则按键永远不匹配
// 功能脉冲：video 域直连比较（ir_cmd 与 ir_valid 同拍非阻塞更新，无竞态；
// 之前的失败根源是 0x20 位跳变未掩码 + 后来引入的跨域数据/沿错位，均已排除）
wire [7:0] ir_code_mask = ir_cmd & 8'hDF;   // 忽略 bit5（44/64、40/60、43/63、09/29 都认）
assign     ir_p44 = ir_valid && (ir_code_mask == 8'h44);
assign     ir_p40 = ir_valid && (ir_code_mask == 8'h40);
assign     ir_p43 = ir_valid && (ir_code_mask == 8'h43);
assign     ir_p09 = ir_valid && (ir_code_mask == 8'h09);


// 诊断：任一功能脉冲触发 → 最右位数码管小数点闪亮 0.5s
//（区分"脉冲没生成"与"功能通路无响应"）
reg        ir_func_dot;
reg [24:0] ir_func_cnt;
always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) begin
        ir_func_dot <= 1'b0;
        ir_func_cnt <= 25'd0;
    end else if (ir_p44 || ir_p40 || ir_p43 || ir_p09) begin
        ir_func_dot <= 1'b1;
        ir_func_cnt <= 25'd0;
    end else if (ir_func_dot) begin
        if (ir_func_cnt == 25'd12_500_000)   // 0.5s @ 25MHz
            ir_func_dot <= 1'b0;
        else
            ir_func_cnt <= ir_func_cnt + 25'd1;
    end
end

// 40/44 虚拟电平的 180ms 保持计数器（ir_lvl40/44 的声明已移到 sd_key_next 之前）
reg [22:0] hold40, hold44;
always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) begin
        ir_lvl40 <= 1'b1; ir_lvl44 <= 1'b1;
        hold40   <= 23'd0; hold44   <= 23'd0;
    end else begin
        if (ir_p40) begin ir_lvl40 <= 1'b0; hold40 <= 23'd0; end
        else if (!ir_lvl40) begin
            if (hold40 == 23'd4_500_000) ir_lvl40 <= 1'b1;
            else hold40 <= hold40 + 23'd1;
        end
        if (ir_p44) begin ir_lvl44 <= 1'b0; hold44 <= 23'd0; end
        else if (!ir_lvl44) begin
            if (hold44 == 23'd4_500_000) ir_lvl44 <= 1'b1;
            else hold44 <= hold44 + 23'd1;
        end
    end
end

// 音乐切换：Mode 3 下按 40 在《欢乐颂》/《小星星》间切换
reg melody_sel;
always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) melody_sel <= 1'b0;
    else if (ir_p40 && (ui_mode == 2'd3))   // 40键切音乐
        melody_sel <= ~melody_sel;
end

ir_receiver #(
    .CLK_HZ (25_000_000)
) u_ir_rx (
    .I_clk      (video_clk),
    .I_rst      (rst_all),
    .I_ir       (ir),
    .O_ir_cmd   (ir_cmd),
    .O_ir_valid (ir_valid)
);

// ir_cmd/ir_valid 跨到 clk 域（50MHz 采 25MHz 域单拍脉冲，2FF 即安全）；
// 只在 valid 边沿更新显示值，其余时间保持最后按下的键值
// cmd 先在本域（video_clk）锁存进保持寄存器：ir_cmd 只在 valid 拍变化，
// 保持值稳定一帧（~100ms），clk 域 2 级同步采样绝对安全。
// （之前的坑：clk 域直接采 ir_cmd，两个时钟沿对齐关系固定时，
//   永远采到解码前的旧值 0x00 —— 小数点亮但恒显示 00）
reg [7:0] ir_cmd_hold;
always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) ir_cmd_hold <= 8'd0;
    else if (ir_valid) ir_cmd_hold <= ir_cmd;
end

reg       ir_v_s1, ir_v_s2;
reg [7:0] ir_cmd_s1, ir_cmd_s2;
reg [7:0] ir_disp;
reg       ir_dot;                    // 调试：解码成功点亮最左位小数点 0.5s
reg [24:0] ir_dot_cnt;
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        ir_v_s1   <= 1'b0;
        ir_v_s2   <= 1'b0;
        ir_cmd_s1 <= 8'd0;
        ir_cmd_s2 <= 8'd0;
        ir_disp   <= 8'd0;
        ir_dot    <= 1'b0;
        ir_dot_cnt <= 25'd0;
    end else begin
        ir_v_s1   <= ir_valid;
        ir_v_s2   <= ir_v_s1;
        ir_cmd_s1 <= ir_cmd_hold;
        ir_cmd_s2 <= ir_cmd_s1;
        if (ir_v_s1 && !ir_v_s2) begin
            ir_disp <= ir_cmd_s2;    // 用 2 级同步后的稳定值
            ir_dot  <= 1'b1;         // 点亮指示
            ir_dot_cnt <= 25'd0;
        end else if (ir_dot) begin
            if (ir_dot_cnt == 25'd25_000_000)   // 0.5s @ 50MHz
                ir_dot <= 1'b0;
            else
                ir_dot_cnt <= ir_dot_cnt + 25'd1;
        end
    end
end

// 左起第 1/2 位数码管显示红外键值（两位十六进制，0~F 全支持）
function [6:0] seg_hex;
    input [3:0] d;
    begin
        case (d)
            4'h0: seg_hex = 7'b1000000;
            4'h1: seg_hex = 7'b1111001;
            4'h2: seg_hex = 7'b0100100;
            4'h3: seg_hex = 7'b0110000;
            4'h4: seg_hex = 7'b0011001;
            4'h5: seg_hex = 7'b0010010;
            4'h6: seg_hex = 7'b0000010;
            4'h7: seg_hex = 7'b1111000;
            4'h8: seg_hex = 7'b0000000;
            4'h9: seg_hex = 7'b0010000;
            4'hA: seg_hex = 7'b0001000;
            4'hB: seg_hex = 7'b0000011;
            4'hC: seg_hex = 7'b1000110;
            4'hD: seg_hex = 7'b0100001;
            4'hE: seg_hex = 7'b0000110;
            4'hF: seg_hex = 7'b0001110;
            default: seg_hex = 7'b1111111;
        endcase
    end
endfunction

wire [6:0] seg_ir_hi = seg_hex(ir_disp[7:4]);
wire [6:0] seg_ir_lo = seg_hex(ir_disp[3:0]);

seg_scan seg_scan_m0(
    .clk               (clk),
    .rst_n             (rst_n),
    .seg_sel           (seg_sel),
    .seg_data          (seg_data),
    .seg_data_0        ({~ir_dot,seg_ir_hi}),   // 左起第 1 位：红外键值高 4 位（小数点=解码指示）
    .seg_data_1        ({1'b1,seg_ir_lo}),   // 左起第 2 位：红外键值低 4 位
    .seg_data_2        ({1'b1,seg_ccb_h}),   // 亮度百位
    .seg_data_3        ({1'b1,seg_ccb_t}),   // 亮度十位
    .seg_data_4        ({1'b1,seg_ccb_u}),   // 亮度个位
    .seg_data_5        ({~ir_func_dot,seg_data_0})   // 小数点=按键功能脉冲指示
);

// ===================== 原图像时序与帧缓存 =====================
video_timing_data video_timing_data_m0(
    .video_clk         (video_clk),
    .rst               (rst_all),
    .read_req          (video_read_req),
    .read_req_ack      (video_read_req_ack),
    .hs                (hs_0),
    .vs                (vs_0),
    .de                (de_0)
);

video_delay video_delay_m0(
    .video_clk         (video_clk),
    .rst               (rst_all),
    .read_en           (video_read_en),
    .read_data         (video_read_data[31:8]),
    .hs                (hs_0),
    .vs                (vs_0),
    .de                (de_0),
    .hs_r              (hs),
    .vs_r              (vs),
    .de_r              (de),
    .vout_data         (vout_data_raw)
);
 // 首图提交前显示红色；提交后一直显示当前显示缓冲区内容
// 时序修复（重建）：display_valid / disp_buf_idx 是 sd_card_clk 域的慢速信号，
// 直连组合像素链（img_effect 乘法器）会形成 15ns 跨域路径（SWNS -5ns → 花屏）。
// 2 级同步到 video_clk 后变为域内路径；慢速信号延迟 2 拍无感。
reg        disp_valid_sync0, disp_valid_sync1;
reg [1:0]  disp_idx_sync0, disp_idx_sync1;
always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) begin
        disp_valid_sync0 <= 1'b0;
        disp_valid_sync1 <= 1'b0;
        disp_idx_sync0   <= 2'd0;
        disp_idx_sync1   <= 2'd0;
    end else begin
        disp_valid_sync0 <= display_valid;
        disp_valid_sync1 <= disp_valid_sync0;
        disp_idx_sync0   <= disp_buf_idx;
        disp_idx_sync1   <= disp_idx_sync0;
    end
end
wire        display_valid_sync = disp_valid_sync1;
wire [1:0]  disp_buf_idx_sync  = disp_idx_sync1;
wire [9:0]  osd_x_cnt, osd_y_cnt;   // osd 像素计数器（渐变背景/波形查询用，提前声明）

// 图片显示：主页菜单（mode0，背景=TF 卡第一张图，sd_card_bmp 的 home_req 保证）、
// 图片轮播（mode1）、图片调节（mode2）；频谱（mode3）保持深蓝→浅蓝渐变背景。
// 渐变用 osd 的当前像素 y 计数器（组合，与像素同拍），经 img_effect/
// osd_overlay 的既有 1 拍流水对齐不变。
// 首图提交前（display_valid=0）显示渐变，上电不再闪红。
wire [1:0]  show_img = (ui_mode != 2'd3) ? 1'b1 : 1'b0;
wire [23:0] grad_rgb = {8'd0, osd_y_cnt[9:2], 8'd200 + {4'b0, osd_y_cnt[9:5]}};

assign vout_data = (show_img && display_valid_sync) ? vout_data_raw : grad_rgb;

// ===================== 图片切换黑场过渡 + 亮度/对比度 =====================
// 插在 vout_data 之后、osd_overlay 之前。
// 为什么要在顶层拦截缓冲索引：sd_card_bmp 在整帧写完时瞬时硬切 disp_buf_idx
// （sd_card_bmp.v:232），直连 frame_read_write 会导致画面突变。
// 这里让 img_effect 拖住缓冲索引，只在画面全黑那一刻才换成新值。
// 像素处理（CC + alpha）为纯组合，不引入通路延迟，故 osd_overlay 的 1 拍对齐不变。
img_effect #(
    .FADE_STEP (8)      // 每帧 alpha 步长 → 约 32 帧渐黑 + 32 帧渐亮 ≈ 1.1s @60fps
) u_img_effect (
    .I_clk        (video_clk),
    .I_rst        (rst_all),
    .I_de         (de),
    .I_hs         (hs),
    .I_vs         (vs),
    .I_rgb        (vout_data),
    .I_brightness (cc_brightness),
    .I_contrast   (cc_contrast),
    .I_switch     (disp_buf_idx_sync != img_buf_idx),  // 组合：新缓冲就绪（已同步）
    .I_target_idx (disp_buf_idx_sync),
    .O_rgb        (img_rgb),
    .O_busy       (img_busy),
    .O_buf_idx    (img_buf_idx)
);

// ===================== Mode 3 音频波形可视化（内部测试音闭环） =====================
// 测试音生成器直接跑在 video_clk 上（内部 /2 使能等效 12.5MHz 节拍，
// 不用板级分频时钟）→ BCLK = 6.25MHz → LRCK ≈ 48.8kHz，
// I2S_receiver 以 video_clk(4x BCLK) 采样恢复 24-bit PCM → audio_waveform
// 缓存 640 点 → osd_overlay 在 mode=3 叠加绿色波浪线。
// 测试音常开（资源极小）；波形显示由 I_wave_en（ui_mode==3）门控。
wire        i2s_bclk, i2s_lrck, i2s_dout;
wire        pcm_valid_125;
wire [23:0] pcm_left_125, pcm_right_125;
wire [15:0] tone_amp;   // 旋律发生器：当前音符峰值，每 0.5s 更新

i2s_test_tone_gen_single_pll_fix64 u_tone (
    .I_clk      (video_clk),
    .I_rst      (rst_all),
    .O_i2s_BCLK (i2s_bclk),
    .O_i2s_LRCK (i2s_lrck),
    .O_i2s_DOUT (i2s_dout),
    .I_sel      (melody_sel),
    .O_amp      (tone_amp)
);

// 接收端用 hdmi_5x(125MHz) 采样 I2S 引脚：20×BCLK 采样余量。
// 原 25MHz 仅 4×BCLK——3 级同步吃掉 3/4 周期，板级路由偏斜让锁定样本
// 错位几个 bit（收到移位后的小常数 → 波形平线 + 静音）。
I2S_receiver u_i2s_rx (
    .I_clk              (hdmi_5x_clk),
    .I_rst              (rst_all),
    .I_i2s_BCLK         (i2s_bclk),
    .I_i2s_LRCK         (i2s_lrck),
    .I_i2s_DOUT         (i2s_dout),
    .O_audio_valid      (pcm_valid_125),
    .O_audio_left_data  (pcm_left_125),
    .O_audio_right_data (pcm_right_125)
);

// ---- 125MHz 域 → video_clk 域 CDC 桥 ----
// valid(1 拍@125MHz) → toggle → video_clk 2 级同步 → 边沿检测；
// 数据 2 级同步（样本周期 ~20µs，跨域期间稳定）。
reg        pcm_tgl_125;
always @(posedge hdmi_5x_clk or posedge rst_all) begin
    if (rst_all) pcm_tgl_125 <= 1'b0;
    else if (pcm_valid_125) pcm_tgl_125 <= ~pcm_tgl_125;
end

reg [2:0]  pcm_tgl_sync;
reg [23:0] pcm_l_sync0, pcm_l_sync1;
reg [23:0] pcm_r_sync0, pcm_r_sync1;
reg        pcm_valid;
always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) begin
        pcm_tgl_sync <= 3'd0;
        pcm_l_sync0  <= 24'd0; pcm_l_sync1 <= 24'd0;
        pcm_r_sync0  <= 24'd0; pcm_r_sync1 <= 24'd0;
        pcm_valid    <= 1'b0;
    end else begin
        pcm_tgl_sync <= {pcm_tgl_sync[1:0], pcm_tgl_125};
        pcm_l_sync0  <= pcm_left_125;
        pcm_l_sync1  <= pcm_l_sync0;
        pcm_r_sync0  <= pcm_right_125;
        pcm_r_sync1  <= pcm_r_sync0;
        pcm_valid    <= pcm_tgl_sync[1] ^ pcm_tgl_sync[2];
    end
end
wire [23:0] pcm_left  = pcm_l_sync1;
wire [23:0] pcm_right = pcm_r_sync1;
// 音频幅值显示：旋律发生器的 0.1s 子窗口峰值（|样本| 高 16 位），随包络起伏
wire [15:0] pcm_amp = tone_amp;

wire       wave_hit;
wire       wave_glow;

// Mode 3 才把测试音送到 HDMI 音频口（测试音按需开启）
wire pcm_valid_m3 = pcm_valid && (ui_mode == 2'd3);

// HDMI 音频时钟恢复参数（ACR）：由音频 valid 流自适应测量，
// 与像素时钟频率无关，25MHz 下同样适用
wire       acr_valid;
wire [19:0] acr_cts, acr_n;
audio_arc_calculate #(
    .ACR_N (6144)
) u_acr (
    .I_clk        (video_clk),
    .I_rst        (rst_all),
    .I_audio_valid(pcm_valid_m3),
    .O_acr_valid  (acr_valid),
    .O_acr_cts    (acr_cts),
    .O_acr_n      (acr_n)
);

// ===================== 频谱柱状图（20 段能量包络，无 FFT） =====================
wire [255:0] spectrum_env;   // 32 柱高度：取各柱峰值（悬停+重力下落，VU 质感）

audio_spectrum u_audio_spectrum (
    .I_clk         (video_clk),
    .I_rst         (rst_all),
    .I_audio_pcm   (pcm_left),
    .I_audio_valid (pcm_valid),
    .O_env         (),
    .O_peak        (spectrum_env)
);

audio_waveform u_audio_wave (
    .I_clk       (video_clk),
    .I_rst       (rst_all),
    .I_pcm       (pcm_left),
    .I_pcm_valid (pcm_valid),
    .I_x         (osd_x_cnt),
    .I_y         (osd_y_cnt),
    .I_de        (de),
    .O_hit       (wave_hit),
    .O_glow      (wave_glow),
    .O_wave_y    ()
);

// ===================== 信息面板行构建：参数 → ASCII =====================
function [7:0] d2a;
    input [3:0] d;
    begin
        d2a = 8'h30 + {4'b0, d};
    end
endfunction

// img_src_w/h 来自 sd_card_clk 域（sd_card_bmp，100MHz）。直接送进 OSD 数字拆分
// 会形成 39 级跨域组合链（P&R 报 -22ns：跨域预算只有 10ns）。
// 时序拆链：先 2 级同步进 video_clk 域再拆位（预算 10ns → 域内 40ns）。
// 宽高只在图片切换时变化，同步丢失采样边沿不影响显示。
reg [15:0] img_w_s0, img_w_s1;
reg [15:0] img_h_s0, img_h_s1;
always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) begin
        img_w_s0 <= 16'd0; img_w_s1 <= 16'd0;
        img_h_s0 <= 16'd0; img_h_s1 <= 16'd0;
    end else begin
        img_w_s0 <= img_src_w;  img_w_s1 <= img_w_s0;
        img_h_s0 <= img_src_h;  img_h_s1 <= img_h_s0;
    end
end

wire [3:0] w_hund = (img_w_s1 / 16'd100) % 16'd10;
wire [3:0] w_ten  = (img_w_s1 / 16'd10) % 16'd10;
wire [3:0] w_one  = img_w_s1 % 16'd10;
wire [3:0] h_hund = (img_h_s1 / 16'd100) % 16'd10;
wire [3:0] h_ten  = (img_h_s1 / 16'd10) % 16'd10;
wire [3:0] h_one  = img_h_s1 % 16'd10;
wire [3:0] b_hund = cc_brightness / 8'd100;
wire [3:0] b_ten  = (cc_brightness % 8'd100) / 8'd10;
wire [3:0] b_one  = cc_brightness % 8'd10;
wire [3:0] c_hund = cc_contrast / 8'd100;
wire [3:0] c_ten  = (cc_contrast % 8'd100) / 8'd10;
wire [3:0] c_one  = cc_contrast % 8'd10;
wire [3:0] a5 = (pcm_amp / 16'd100000) % 16'd10;
wire [3:0] a4 = (pcm_amp / 16'd10000) % 16'd10;
wire [3:0] a3 = (pcm_amp / 16'd1000) % 16'd10;
wire [3:0] a2 = (pcm_amp / 16'd100) % 16'd10;
wire [3:0] a1 = (pcm_amp / 16'd10) % 16'd10;
wire [3:0] a0 = pcm_amp % 16'd10;

// 宽高按 3 位十进制定位（演示图 ≤999；超过时低位截断显示）
// 面板 4 行 × 14 字符（112bit），字符→cell 映射见 osd_overlay.ascii_cell；
// 中文用直通码 0x80 + cell 号（cell 布局：33 图/34 片/45 分/46 辨/48 率/
// 49 对/50 比/51 度/52 亮）
// Mode 1：图片 800x600
// Mode 2：分辨率 800x600 / 亮度 100 / 对比度 100
// Mode 3：AUDIO / FREQ 1kHz / SAMPLE 48830Hz / AMP + 6 位幅值（前导零填空白）
localparam [7:0] C_TU    = 8'h80 + 8'd33;   // 图
localparam [7:0] C_PIAN  = 8'h80 + 8'd34;   // 片
localparam [7:0] C_FEN   = 8'h80 + 8'd45;   // 分
localparam [7:0] C_BIAN  = 8'h80 + 8'd46;   // 辨
localparam [7:0] C_LV    = 8'h80 + 8'd48;   // 率
localparam [7:0] C_DUI   = 8'h80 + 8'd49;   // 对
localparam [7:0] C_BI    = 8'h80 + 8'd50;   // 比
localparam [7:0] C_DU    = 8'h80 + 8'd51;   // 度
localparam [7:0] C_LIANG = 8'h80 + 8'd52;   // 亮

wire [7:0] amp_c5 = (pcm_amp >= 16'd100000) ? d2a(a5) : " ";
wire [7:0] amp_c4 = (pcm_amp >= 16'd10000)  ? d2a(a4) : " ";
wire [7:0] amp_c3 = (pcm_amp >= 16'd1000)   ? d2a(a3) : " ";
wire [7:0] amp_c2 = (pcm_amp >= 16'd100)    ? d2a(a2) : " ";
wire [7:0] amp_c1 = (pcm_amp >= 16'd10)     ? d2a(a1) : " ";
wire [7:0] amp_c0 = d2a(a0);

wire [111:0] line1 = (ui_mode == 2'd1) ? {C_TU, C_PIAN, " ", d2a(w_hund), d2a(w_ten), d2a(w_one),
                                          "x", d2a(h_hund), d2a(h_ten), d2a(h_one), "    "} :
                     (ui_mode == 2'd2) ? {C_FEN, C_BIAN, C_LV, " ", d2a(w_hund), d2a(w_ten), d2a(w_one),
                                          "x", d2a(h_hund), d2a(h_ten), d2a(h_one), "   "} :
                     "AUDIO         ";
wire [111:0] line2 = (ui_mode == 2'd2) ? {C_LIANG, C_DU, " ", d2a(b_hund), d2a(b_ten), d2a(b_one), "        "} :
                     (ui_mode == 2'd3) ? "FREQ 1kHz     " : "              ";
wire [111:0] line3 = (ui_mode == 2'd2) ? {C_DUI, C_BI, C_DU, " ", d2a(c_hund), d2a(c_ten), d2a(c_one), "       "} :
                     (ui_mode == 2'd3) ? "SAMPLE 48830Hz " : "              ";
wire [111:0] line4 = (ui_mode == 2'd3) ? {"AMP ", amp_c5, amp_c4, amp_c3,
                                          amp_c2, amp_c1, amp_c0, "    "} :
                    "              ";

// 时序拆链：面板 4 行 1 拍寄存。宽高/参数的 ÷100/÷10 拆位链（20 级加法器）
// 只到 r_line 为止；osd 逐像素通路只剩行 mux + 字模查表（短路径）。
// 行内容整帧不变（只在切图/调参时变），1 拍滞后不可见。
reg [111:0] r_line1, r_line2, r_line3, r_line4;
always @(posedge video_clk or posedge rst_all) begin
    if (rst_all) begin
        r_line1 <= 112'd0;
        r_line2 <= 112'd0;
        r_line3 <= 112'd0;
        r_line4 <= 112'd0;
    end else begin
        r_line1 <= line1;
        r_line2 <= line2;
        r_line3 <= line3;
        r_line4 <= line4;
    end
end

// ===================== OSD 滚动字幕叠加 =====================
osd_overlay #(
    .H_ACTIVE        (640),
    .V_ACTIVE        (480),
    .TEXT_CELLS      (128),         // 128 cell = 4096 行，addr 12 位（32x32 字模）
    .MENU_ITEMS      (3),
    .MENU_Y_TOP      (400),         // 屏幕下方单行（400+32=432 < 480）
    .MENU_X_LEFT     (96),          // (640-14*32)/2，3 项水平居中（项间多 1 空列）
    .MENU_TEXT_COLOR (24'hFFFFFF),
    .MENU_SEL_COLOR  (24'hFFFF00),
    .PANEL_X_LEFT    (176),         // 640 - 14*32 - 16，32px 字模防超屏
    .PANEL_Y_TOP     (20),
    .PANEL_COLOR     (24'hFFFFFF)
) osd_overlay_m0 (
    .I_clk           (video_clk),
    .I_rst           (rst_all),
    .I_de            (de),
    .I_hs            (hs),
    .I_vs            (vs),
    .I_rgb           (img_rgb),
    .I_osd_en        (ui_mode == 2'd1),   // 滚动字幕仅在 Mode1（图片播放）显示
    .I_scroll_offset (12'd0),
    .I_menu_en       (ui_menu_en),
    .I_menu_sel      (ui_menu_sel),
    .I_wave_en       (ui_mode == 2'd3),   // Mode 3：波形叠加在最上层
    .I_wave_hit      (wave_hit),
    .I_wave_glow     (wave_glow),
    .I_spectrum_en   (ui_mode == 2'd3),   // Mode 3：频谱柱状图
    .I_env           (spectrum_env),
    .I_info_en       (ui_mode != 2'd0),   // 非菜单模式：信息面板
    .I_line1         (r_line1),
    .I_line2         (r_line2),
    .I_line3         (r_line3),
    .I_line4         (r_line4),
    .O_x_cnt         (osd_x_cnt),
    .O_y_cnt         (osd_y_cnt),
    .O_de            (osd_de),
    .O_hs            (osd_hs),
    .O_vs            (osd_vs),
    .O_rgb           (osd_rgb),
    .O_osd_on        (osd_on)
);

frame_read_write #(
    .WRITE_V_FLIP     (1),
    .FRAME_WIDTH      (640),
    .FRAME_HEIGHT     (480)
) frame_read_write_m0(
    .mem_clk           (ext_mem_clk),
    .rst               (rst_all),
    .Sdr_init_done     (Sdr_init_done),
    .Sdr_init_ref_vld  (Sdr_init_ref_vld),
    .Sdr_busy          (Sdr_busy),

    .App_rd_en         (App_rd_en),
    .App_rd_addr       (App_rd_addr),
    .Sdr_rd_en         (Sdr_rd_en),
    .Sdr_rd_dout       (Sdr_rd_dout),

    .read_clk          (video_clk),
    .read_req          (video_read_req),
    .read_req_ack      (video_read_req_ack),
    .read_finish       (),
    .read_addr_0       (BUF0_ADDR),
    .read_addr_1       (BUF1_ADDR),
    .read_addr_2       (24'd0),
    .read_addr_3       (24'd0),
    .read_addr_index   (img_buf_idx),
    .read_len          (FRAME_PIXELS),
    .read_en           (video_read_en),
    .read_data         (video_read_data),

    .App_wr_en         (App_wr_en),
    .App_wr_addr       (App_wr_addr),
    .App_wr_din        (App_wr_din),
    .App_wr_dm         (App_wr_dm),

    .write_clk         (sd_card_clk),
    .write_req         (sd_card_write_req),
    .write_req_ack     (sd_card_write_req_ack),
    .write_finish      (frame_write_finish),
    .write_addr_0      (BUF0_ADDR),
    .write_addr_1      (BUF1_ADDR),
    .write_addr_2      (24'd0),
    .write_addr_3      (24'd0),
    .write_addr_index  (write_buf_idx),
    .write_len         (FRAME_PIXELS),
    .write_en          (sd_card_write_en),
    .write_data        (sd_card_write_data)
);

sdram U3(
    .Clk               (ext_mem_clk),
    .Clk_sft           (ext_mem_clk_sft),
    .Rst               (rst_all),
    .Sdr_init_done     (Sdr_init_done),
    .Sdr_init_ref_vld  (Sdr_init_ref_vld),
    .Sdr_busy          (Sdr_busy),
    .App_wr_en         (App_wr_en),
    .App_wr_addr       (App_wr_addr),
    .App_wr_dm         (App_wr_dm),
    .App_wr_din        (App_wr_din),
    .App_rd_en         (App_rd_en),
    .App_rd_addr       (App_rd_addr),
    .Sdr_rd_en         (Sdr_rd_en),
    .Sdr_rd_dout       (Sdr_rd_dout)
);

// ===================== RGB/DE 转 AXIS 视频 =====================
// 注意：必须接 osd_* 而不是原始的 vs/de/vout_data。
// osd_overlay 为字模 ROM 的同步读引入了统一的 1 拍延迟，
// 像素与 vs/de 必须同源，否则画面会相对同步信号错位 1 像素。
video_rgb_to_axis_640x480 u_video_rgb_to_axis_640x480(
    .I_clk         (video_clk),
    .I_rst         (rst_all),
    .I_vs          (osd_vs),
    .I_de          (osd_de),
    .I_rgb         (osd_rgb),
    .O_video_user  (axis_s_user),
    .O_video_valid (axis_s_valid),
    .O_video_last  (axis_s_last),
    .O_video_data  (axis_s_data)
);

// 上电后自动打一拍，触发一次 EDID 读取。
// 时序修复：原 4ms 太早（HDMI 核刚出复位、显示器握手未完成，EDID 读失败
// → 核按"无音频能力"处理 → 静音但视频回退参数照常）。推迟到 500ms。
startup_pulse #(
    .CNT_MAX(24'd12_500_000)   // 500ms @25MHz
) u_startup_pulse (
    .I_clk   (video_clk),
    .I_rst   (rst_all),
    .O_pulse (edid_trig)
);

// ===================== HDMI 1.4b 发射 =====================
hdmi_1_4b_transmitter_core_wrapper #(
    .DEVICE                 ( "EG"       ),
    .HTOTAL                 ( 800        ),
    .HSA                    ( 96         ),
    .HFP                    ( 16         ),
    .HBP                    ( 48         ),
    .HACTIVE                ( 640        ),
    .VTOTAL                 ( 525        ),
    .VSA                    ( 2          ),
    .VFP                    ( 10         ),
    .VBP                    ( 33         ),
    .VACTIVE                ( 480        ),
    .VIDEO_VIC              ( 1          ),
    .VIDEO_TPG              ( "Disable"  ),
    .VIDEO_FORMAT           ( "RGB"      ),
    .AUDIO_SAMPLE_RATE      ( "48K"      ),
    .IIC_SCL_DIV            ( 250        )
) u_hdmi_1_4b_transmitter_core_wrapper(
    .I_pixel_clk        (video_clk),
    .I_rst              (rst_all),
    .I_edid_read_trig   (edid_trig),
    .O_edid_read_valid  (edid_valid),
    .O_edid_read_data   (edid_data),

    .I_axis_s_user      (axis_s_user),
    .I_axis_s_valid     (axis_s_valid),
    .I_axis_s_last      (axis_s_last),
    .I_axis_s_data      (axis_s_data),
    .O_axis_s_ready     (axis_s_ready),

    .I_audio_valid      (pcm_valid_m3),
    .I_audio_left_data  (pcm_left),
    .I_audio_right_data (pcm_right),
    .I_acr_valid        (acr_valid),
    .I_acr_cts          (acr_cts),
    .I_acr_n            (acr_n),

    .O_video_locked     (),
    .O_ddc_scl          (HDMI_DDC_SCL),
    .IO_ddc_sda         (HDMI_DDC_SDA),

    .O_ch0_tmds_data    (tmds_ch0_data),
    .O_ch1_tmds_data    (tmds_ch1_data),
    .O_ch2_tmds_data    (tmds_ch2_data),
    .O_clk_tmds_data    (tmds_clk_data)
);

hdmi_phy_wrapper #(
    .DEVICE ( "EG" )
) u_hdmi2phy_wrapper(
    .I_pixel_clk        (video_clk),
    .I_serial_clk       (hdmi_5x_clk),
    .I_rst              (rst_all),
    .I_tmds_channel_0   (tmds_ch0_data),
    .I_tmds_channel_1   (tmds_ch1_data),
    .I_tmds_channel_2   (tmds_ch2_data),
    .I_tmds_channel_clk (tmds_clk_data),
    .O_tmds_ch0_p       (HDMI_D0_P),
    .O_tmds_ch1_p       (HDMI_D1_P),
    .O_tmds_ch2_p       (HDMI_D2_P),
    .O_tmds_clk_p       (HDMI_CLK_P)
);

endmodule